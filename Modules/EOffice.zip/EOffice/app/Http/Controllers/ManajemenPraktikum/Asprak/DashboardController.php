<?php

namespace Modules\EOffice\Http\Controllers\ManajemenPraktikum\Asprak;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\EOffice\Models\Absensi;
use Modules\EOffice\Models\AsistenPraktikum;
use Modules\EOffice\Models\ModulAsprak;
use Modules\EOffice\Models\Pengumuman;
use Modules\EOffice\Models\PengumpulanTugas;
use Modules\EOffice\Models\Tugas;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $asprak = AsistenPraktikum::with(['praktikum.dosen', 'modulAsprak.modul'])
            ->where('user_id', $user->id)
            ->where('role', 'asprak')
            ->whereNull('deleted_at')
            ->first();

        $modulDiampu = ModulAsprak::with(['modul.materi', 'modul.tugas'])
            ->where('asprak_id', $asprak?->id)
            ->get()
            ->pluck('modul');

        $totalModul  = $modulDiampu->count();
        $totalMateri = $modulDiampu->sum(fn($m) => $m?->materi?->count() ?? 0);

        // Pengumpulan tugas yang belum dinilai (status: belum_dicek)
        $tugasPendingNilai = PengumpulanTugas::whereHas(
                'tugas.modul.modulAsprak', fn($q) => $q->where('asprak_id', $asprak?->id)
            )
            ->where('status_pengumpulan', PengumpulanTugas::STATUS_BELUM_DICEK)
            ->count();

        $absensiHariIni = Absensi::whereHas('modul.modulAsprak', fn($q) => $q->where('asprak_id', $asprak?->id))
            ->whereDate('tanggal', today())
            ->count();

        $tugasMendatang = Tugas::whereHas('modul.modulAsprak', fn($q) => $q->where('asprak_id', $asprak?->id))
            ->where('deadline', '>=', now())
            ->orderBy('deadline')
            ->limit(5)
            ->get();

        $pengumpulanPending = PengumpulanTugas::with(['tugas', 'daftarPraktikan.user'])
            ->whereHas('tugas.modul.modulAsprak', fn($q) => $q->where('asprak_id', $asprak?->id))
            ->where('status_pengumpulan', PengumpulanTugas::STATUS_BELUM_DICEK)
            ->orderByDesc('created_at')
            ->limit(5)
            ->get();

        // Pengumuman terbaru di praktikum asprak ini
        $pengumumanTerbaru = $asprak
            ? Pengumuman::where('praktikum_id', $asprak->praktikum_id)
                ->orderByDesc('created_at')
                ->limit(3)
                ->get()
            : collect();

        return view('eoffice::manajemen-praktikum.asprak.dashboard', compact(
            'asprak',
            'modulDiampu',
            'totalModul',
            'totalMateri',
            'tugasPendingNilai',
            'absensiHariIni',
            'tugasMendatang',
            'pengumpulanPending',
            'pengumumanTerbaru'
        ));
    }
}
