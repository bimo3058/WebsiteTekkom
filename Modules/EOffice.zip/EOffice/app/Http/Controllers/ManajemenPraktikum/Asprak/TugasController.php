<?php

namespace Modules\EOffice\Http\Controllers\ManajemenPraktikum\Asprak;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\EOffice\Models\AsistenPraktikum;
use Modules\EOffice\Models\Modul;
use Modules\EOffice\Models\ModulAsprak;
use Modules\EOffice\Models\PengumpulanTugas;
use Modules\EOffice\Models\Tugas;

class TugasController extends Controller
{
    public function index()
    {
        $user   = auth()->user();
        $asprak = AsistenPraktikum::where('user_id', $user->id)->whereNull('deleted_at')->first();

        $modulIds = $asprak
            ? ModulAsprak::where('asprak_id', $asprak->id)->pluck('modul_id')
            : collect();

        $tugas = Tugas::whereIn('modul_id', $modulIds)
            ->with('modul.praktikum')
            ->withCount([
                'pengumpulan',
                'pengumpulan as pengumpulan_acc_count'    => fn($q) => $q->where('status_pengumpulan', 'acc'),
                'pengumpulan as pengumpulan_revisi_count' => fn($q) => $q->where('status_pengumpulan', 'revisi'),
            ])
            ->orderByDesc('created_at')
            ->get();

        return view('eoffice::manajemen-praktikum.asprak.tugas', compact('tugas'));
    }

    public function create()
    {
        $user   = auth()->user();
        $asprak = AsistenPraktikum::where('user_id', $user->id)->whereNull('deleted_at')->first();

        $moduls = $asprak
            ? ModulAsprak::where('asprak_id', $asprak->id)->with('modul.praktikum')->get()->pluck('modul')
            : collect();

        return view('eoffice::manajemen-praktikum.asprak.tugas-create', compact('moduls'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'modul_id'     => 'required|exists:modul_praktikum,id',
            'judul'        => 'required|string|max:255',
            'deskripsi'    => 'nullable|string',
            'deadline'     => 'nullable|date',
            'is_published' => 'boolean',
        ]);

        Tugas::create($request->only(['modul_id', 'judul', 'deskripsi', 'deadline', 'is_published']));

        return redirect()->route('eoffice.manprak.asprak.tugas.index')->with('success', 'Tugas berhasil dibuat.');
    }

    public function update(Request $request, int $id)
    {
        $request->validate([
            'judul'        => 'required|string|max:255',
            'deskripsi'    => 'nullable|string',
            'deadline'     => 'nullable|date',
            'is_published' => 'boolean',
        ]);

        Tugas::findOrFail($id)->update($request->only(['judul', 'deskripsi', 'deadline', 'is_published']));

        return back()->with('success', 'Tugas berhasil diperbarui.');
    }

    public function destroy(int $id)
    {
        Tugas::findOrFail($id)->delete();

        return back()->with('success', 'Tugas berhasil dihapus.');
    }

    public function pengumpulan(int $id)
    {
        $tugas       = Tugas::with('modul.praktikum')->findOrFail($id);
        $pengumpulan = PengumpulanTugas::where('tugas_id', $id)
            ->with('daftarPraktikan.user')
            ->orderByDesc('created_at')
            ->get();

        return view('eoffice::manajemen-praktikum.asprak.tugas-pengumpulan', compact('tugas', 'pengumpulan'));
    }

    /**
     * Beri nilai sekaligus set status ACC.
     * Nilai tugas langsung masuk ke tabel nilai_praktikum (auto-sync).
     */
    public function beriNilai(Request $request, int $id)
    {
        $request->validate([
            'nilai' => 'required|numeric|min:0|max:100',
        ]);

        $pengumpulan = PengumpulanTugas::with('daftarPraktikan')->findOrFail($id);

        $pengumpulan->update([
            'nilai'              => $request->nilai,
            'status_pengumpulan' => PengumpulanTugas::STATUS_ACC,
            'catatan_revisi'     => null,
            'is_revision'        => false,
        ]);

        // Auto-sync nilai ke tabel nilai_praktikum
        $this->syncNilaiTugas($pengumpulan);

        return back()->with('success', 'Nilai berhasil disimpan dan status diubah ke ACC.');
    }

    /**
     * Beri revisi — kirim catatan, set status revisi, boleh lampirkan file balik.
     */
    public function beriRevisi(Request $request, int $id)
    {
        $request->validate([
            'catatan_revisi' => 'required|string',
        ]);

        PengumpulanTugas::findOrFail($id)->update([
            'catatan_revisi'     => $request->catatan_revisi,
            'is_revision'        => true,
            'status_pengumpulan' => PengumpulanTugas::STATUS_REVISI,
        ]);

        return back()->with('success', 'Revisi berhasil dikirim ke mahasiswa.');
    }

    /**
     * Sync nilai tugas rata-rata ke tabel nilai_praktikum.
     * Nilai akhir dihitung dari rata-rata nilai semua tugas pada praktikum.
     */
    private function syncNilaiTugas(PengumpulanTugas $pengumpulan): void
    {
        try {
            $daftarPraktikanId = $pengumpulan->daftar_praktikan_id;

            // Rata-rata nilai seluruh tugas yang sudah dinilai untuk praktikan ini
            $rataRataNilaiTugas = PengumpulanTugas::where('daftar_praktikan_id', $daftarPraktikanId)
                ->whereNotNull('nilai')
                ->avg('nilai');

            \Modules\EOffice\Models\Nilai::updateOrCreate(
                ['daftar_praktikan_id' => $daftarPraktikanId],
                ['nilai_tugas' => round($rataRataNilaiTugas, 2)]
            );
        } catch (\Throwable) {
            // Jangan crash karena gagal sync
        }
    }
}
