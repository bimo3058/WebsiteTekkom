<?php

namespace Modules\EOffice\Http\Controllers\ManajemenPraktikum\Admin;

use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\EOffice\Models\AsprakPraktikum;
use Modules\EOffice\Models\PendaftaranKoordinator;
use Modules\EOffice\Models\Praktikum;
use Modules\EOffice\Services\NotifikasiService;

/**
 * Admin: Lihat & final-approve pendaftaran koor.
 * Flow: Mahasiswa → Dosen review (status_dosen) → Admin final approve (status).
 * Admin hanya bisa approve jika dosen sudah approve (status_dosen = disetujui).
 */
class PendaftaranKoorController extends Controller
{
    public function __construct(protected NotifikasiService $notif) {}

    public function index(Request $request)
    {
        $query = PendaftaranKoordinator::with(['user', 'praktikum', 'direviewOleh'])
            ->orderByDesc('created_at');

        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }
        if ($statusDosen = $request->input('status_dosen')) {
            $query->where('status_dosen', $statusDosen);
        }
        if ($search = $request->input('search')) {
            $query->whereHas('user', fn($q) => $q->where('name', 'like', "%{$search}%"));
        }

        $pendaftaran = $query->paginate(15)->withQueryString();

        return view('eoffice::manajemen-praktikum.admin.pendaftaran-koor', compact('pendaftaran'));
    }

    /**
     * Admin final-approve: assign role koor_prak otomatis.
     * Hanya bisa jika dosen sudah setujui.
     */
    public function approve(Request $request, int $id)
    {
        $pendaftaran = PendaftaranKoordinator::with(['user', 'praktikum'])->findOrFail($id);

        if ($pendaftaran->status !== 'pending') {
            return back()->with('error', 'Pendaftaran ini sudah diproses.');
        }
        if ($pendaftaran->status_dosen !== 'disetujui') {
            return back()->with('error', 'Pendaftaran ini belum disetujui oleh dosen pengampu. Tunggu review dosen terlebih dulu.');
        }

        $pendaftaran->update(['status' => 'approved']);

        $user     = $pendaftaran->user;
        $roleKoor = Role::where('name', 'koor_prak')->where('module', 'eoffice')->first();

        if ($user && $roleKoor) {
            $user->roles()->syncWithoutDetaching([$roleKoor->id]);
        }

        // Set koor_id di praktikum
        Praktikum::where('id', $pendaftaran->praktikum_id)
            ->update(['koor_id' => $pendaftaran->user_id]);

        // Tambahkan ke asprak_praktikum dengan role koor
        AsprakPraktikum::firstOrCreate([
            'praktikum_id' => $pendaftaran->praktikum_id,
            'user_id'      => $pendaftaran->user_id,
        ], ['role' => 'koor']);

        // Notifikasi ke user
        $this->notif->kirim(
            $pendaftaran->user_id,
            'Pendaftaran Koordinator Diterima',
            "Selamat! Anda diterima sebagai Koordinator Praktikum {$pendaftaran->praktikum?->nama}."
        );

        return back()->with('success', "Pendaftaran koordinator {$user?->name} berhasil diterima. Role koor_prak telah di-assign.");
    }

    public function reject(Request $request, int $id)
    {
        $pendaftaran = PendaftaranKoordinator::with('user')->findOrFail($id);

        if ($pendaftaran->status !== 'pending') {
            return back()->with('error', 'Pendaftaran ini sudah diproses.');
        }

        $pendaftaran->update([
            'status'           => 'rejected',
            'alasan_penolakan' => $request->input('alasan_penolakan'),
        ]);

        $this->notif->kirim(
            $pendaftaran->user_id,
            'Pendaftaran Koordinator Ditolak',
            "Pendaftaran koordinator Anda untuk praktikum {$pendaftaran->praktikum?->nama} tidak diterima."
                . ($request->input('alasan_penolakan') ? " Alasan: {$request->input('alasan_penolakan')}" : '')
        );

        return back()->with('success', "Pendaftaran koordinator {$pendaftaran->user?->name} ditolak.");
    }
}