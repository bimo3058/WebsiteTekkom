<?php

namespace Modules\EOffice\Http\Controllers\ManajemenPraktikum\Dosen;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\EOffice\Models\AsprakPraktikum;
use Modules\EOffice\Models\DaftarPraktikan;
use Modules\EOffice\Models\Modul;
use Modules\EOffice\Models\Nilai;
use Modules\EOffice\Models\PendaftaranKoordinator;
use Modules\EOffice\Models\Praktikum;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $praktikums = Praktikum::with(['koordinator', 'modul'])
            ->where('dosen_id', $user->id)
            ->withCount(['daftarPraktikan', 'modul', 'asprakPraktikum'])
            ->orderByDesc('created_at')
            ->get();

        $totalPraktikumDiampu = $praktikums->count();
        $totalPraktikumAktif  = $praktikums->where('status', 'aktif')->count();
        $totalMahasiswa       = $praktikums->sum('daftar_praktikan_count');
        $totalModul           = $praktikums->sum('modul_count');

        // Praktikum yang belum punya koordinator
        $praktikumTanpaKoor = $praktikums->whereNull('koor_id')->values();

        // Pendaftaran koordinator yang pending (perlu tindakan dosen)
        $pendaftaranKoorPending = PendaftaranKoordinator::with(['user', 'praktikum'])
            ->whereHas('praktikum', fn($q) => $q->where('dosen_id', $user->id))
            ->where('status', 'pending')
            ->orderByDesc('created_at')
            ->get();

        // Nilai yang belum diapprove dosen
        $nilaiMenungguApproval = Nilai::whereHas('daftarPraktikan.praktikum', fn($q) => $q->where('dosen_id', $user->id))
            ->where('disetujui_koor', true)
            ->where('disetujui_dosen', false)
            ->count();

        $semesterLabel = 'Semester Genap 2025/2026';

        return view('eoffice::manajemen-praktikum.dosen.dashboard', compact(
            'praktikums',
            'totalPraktikumDiampu',
            'totalPraktikumAktif',
            'totalMahasiswa',
            'totalModul',
            'praktikumTanpaKoor',
            'nilaiMenungguApproval',
            'pendaftaranKoorPending',
            'semesterLabel'
        ));
    }

    /**
     * Tunjuk koordinator dari NIM mahasiswa.
     */
    public function tunjukKoor(Request $request)
    {
        $request->validate([
            'praktikum_id' => 'required|uuid|exists:eo_praktikum,id',
            'nim'          => 'required|string',
        ]);

        $user = auth()->user();

        $praktikum = Praktikum::where('id', $request->praktikum_id)
            ->where('dosen_id', $user->id)
            ->firstOrFail();

        // Cari user berdasarkan NIM (student_number di tabel students)
        $targetUser = User::whereHas('student', fn($q) => $q->where('student_number', $request->nim))
            ->first();

        if (!$targetUser) {
            return back()->with('error', "Mahasiswa dengan NIM {$request->nim} tidak ditemukan.");
        }

        // Pastikan mahasiswa sudah terdaftar di praktikum ini
        $terdaftar = DaftarPraktikan::where('praktikum_id', $praktikum->id)
            ->where('user_id', $targetUser->id)
            ->exists();

        if (!$terdaftar) {
            return back()->with('error', 'Mahasiswa ini tidak terdaftar di praktikum tersebut.');
        }

        // Assign role koor_prak
        $roleKoor = \App\Models\Role::where('name', 'koor_prak')
            ->where('module', 'eoffice')
            ->first();

        if ($roleKoor && !$targetUser->hasRole('koor_prak')) {
            $targetUser->roles()->syncWithoutDetaching([$roleKoor->id]);
        }

        // Update koor_id di praktikum
        $praktikum->update(['koor_id' => $targetUser->id]);

        // Tambahkan ke asprak_praktikum dengan role koor (jika belum)
        AsprakPraktikum::firstOrCreate([
            'praktikum_id' => $praktikum->id,
            'user_id'      => $targetUser->id,
        ], [
            'role' => 'koor',
        ]);

        return back()->with('success', "Mahasiswa {$targetUser->name} berhasil ditunjuk sebagai koordinator.");
    }
}
