<?php

return [
    'name' => 'EOffice',
];
