<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="csrf-token" content="{{ csrf_token() }}">
<title>{{ $pageTitle ?? 'Manajemen Praktikum' }} — SIPERKOM</title>
@vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="h-full overflow-hidden bg-[#F6F8FA] text-[#0D0D12] antialiased" style="font-family:'Inter Tight',system-ui,sans-serif;">

@php
    $user         = auth()->user();
    $name         = $user->name;
    $initials     = strtoupper(substr($name, 0, 1));
    $sp           = strpos($name, ' ');
    if ($sp !== false) $initials .= strtoupper(substr($name, $sp + 1, 1));
    $currentRoute = request()->route()?->getName() ?? '';

    // Cek semua role yang dimiliki user — multi-role support
    $isAdmin  = $user->hasRole('superadmin') || $user->hasRole('admin_eoffice');
    $isDosen  = $user->hasRole('dosen');
    $isKoor   = $user->hasRole('koor_prak');
    $isAsprak = $user->hasRole('asprak');
    // Mahasiswa selalu ada (semua user bisa jadi mahasiswa praktikum)

    // Icon path strings
    $iHome    = "M4.8787 8.90834L10.5858 3.54999C11.3669 2.81667 12.6332 2.81667 13.4142 3.54999L19.1213 8.90834M4.8787 8.90834C4.31629 9.43653 4.00002 10.1531 4.00002 10.9V18.1833C4.00002 19.7389 5.34317 21 7.00002 21H9V16C9 14.8954 9.89543 14 11 14H13C14.1046 14 15 14.8954 15 16V21H17C18.6569 21 20 19.7389 20 18.1833V10.9C20 10.153 19.684 9.43656 19.1213 8.90834M4.8787 8.90834L3.00031 10.6722M19.1213 8.90834L21 10.6722";
    $iList    = "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2";
    $iUser    = "M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2M12 11a4 4 0 100-8 4 4 0 000 8z";
    $iCheck   = "M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z";
    $iBook    = "M4 19.5A2.5 2.5 0 016.5 17H20M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z";
    $iBell    = "M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 01-3.46 0";
    $iBack    = "M19 12H5M5 12l7-7M5 12l7 7";
    $iLogout  = "M13 8.73V8.14C13 6.58 12.19 5.24 11.07 4.94L7.87 4.06C6.39 3.66 5 5.21 5 7.27v9.46C5 18.79 6.39 20.34 7.87 19.94l3.2-.87C12.19 18.76 13 17.42 13 15.86v-.59M11 12h8M19 12l-2.5-2.72M19 12l-2.5 2.72";
    $iCal     = "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z";
    $iEdit    = "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z";
    $iGear    = "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z";

    // Definisi section per role — tiap section muncul jika user punya role terkait
    $sections = [];

    if ($isAdmin) {
        $sections[] = [
            'label' => 'Admin',
            'color' => '#DF1C41',
            'bg'    => 'rgba(223,28,65,0.08)',
            'match' => 'manprak.admin',
            'groups' => [
                'Utama' => [
                    ['href' => route('eoffice.manprak.admin.dashboard'),                    'label' => 'Dashboard',          'match' => 'admin.dashboard',          'icon' => $iHome],
                ],
                'Kelola Data' => [
                    ['href' => route('eoffice.manprak.admin.praktikum.index'),              'label' => 'Daftar Praktikum',   'match' => 'admin.praktikum',          'icon' => $iBook],
                    ['href' => route('eoffice.manprak.admin.matkul-praktikum.index'),       'label' => 'Matkul Praktikum',   'match' => 'matkul-praktikum',         'icon' => $iList],
                    ['href' => route('eoffice.manprak.admin.dosen.index'),                  'label' => 'Daftar Dosen',       'match' => 'admin.dosen',              'icon' => $iUser],
                    ['href' => route('eoffice.manprak.admin.asprak.index'),                 'label' => 'Asisten Praktikum',  'match' => 'admin.asprak',             'icon' => $iUser],
                    ['href' => route('eoffice.manprak.admin.daftar-praktikan.index'),       'label' => 'Daftar Praktikan',   'match' => 'daftar-praktikan',         'icon' => $iList],
                ],
                'Pendaftaran' => [
                    ['href' => route('eoffice.manprak.admin.periode-pendaftaran.index'),    'label' => 'Periode Pendaftaran','match' => 'periode-pendaftaran',      'icon' => $iCal],
                    ['href' => route('eoffice.manprak.admin.pendaftaran-koor.index'),       'label' => 'Pendaftaran Koor',   'match' => 'pendaftaran-koor',         'icon' => $iCheck],
                    ['href' => route('eoffice.manprak.admin.pendaftaran-asprak.index'),     'label' => 'Pendaftaran Asprak', 'match' => 'pendaftaran-asprak',       'icon' => $iList],
                    ['href' => route('eoffice.manprak.admin.bagi-asprak.index'),            'label' => 'Distribusi Asprak',  'match' => 'bagi-asprak',              'icon' => $iGear],
                ],
            ],
        ];
    }

    if ($isDosen) {
        $sections[] = [
            'label' => 'Dosen',
            'color' => '#0B266E',
            'bg'    => 'rgba(11,38,110,0.08)',
            'match' => 'manprak.dosen',
            'groups' => [
                'Utama' => [
                    ['href' => route('eoffice.manprak.dosen.dashboard'),                             'label' => 'Dashboard',        'match' => 'dosen.dashboard',        'icon' => $iHome],
                ],
                'Kelola' => [
                    ['href' => route('eoffice.manprak.dosen.pendaftaran-koor.index'),                'label' => 'Seleksi Koor',     'match' => 'dosen.pendaftaran-koor', 'icon' => $iCheck],
                    ['href' => route('eoffice.manprak.dosen.asprak.index'),                          'label' => 'Asisten Praktikum','match' => 'dosen.asprak',           'icon' => $iUser],
                    ['href' => route('eoffice.manprak.dosen.daftar-praktikan.index'),                'label' => 'Daftar Praktikan', 'match' => 'dosen.daftar-praktikan', 'icon' => $iList],
                ],
                'Konten' => [
                    ['href' => route('eoffice.manprak.dosen.pengumuman.index'),                      'label' => 'Pengumuman',       'match' => 'dosen.pengumuman',       'icon' => $iBell],
                    ['href' => route('eoffice.manprak.dosen.modul.index', ['praktikumId' => 0]),    'label' => 'Daftar Modul',     'match' => 'dosen.modul',            'icon' => $iBook],
                    ['href' => route('eoffice.manprak.dosen.tugas.index'),                           'label' => 'Daftar Tugas',     'match' => 'dosen.tugas',            'icon' => $iList],
                    ['href' => route('eoffice.manprak.dosen.nilai.index', ['praktikumId' => 0]),    'label' => 'Absensi & Nilai',  'match' => 'dosen.nilai',            'icon' => $iCheck],
                ],
            ],
        ];
    }

    if ($isKoor) {
        $sections[] = [
            'label' => 'Koordinator',
            'color' => '#6366F1',
            'bg'    => 'rgba(99,102,241,0.08)',
            'match' => 'manprak.koor',
            'groups' => [
                'Utama' => [
                    ['href' => route('eoffice.manprak.koor.dashboard'),                'label' => 'Dashboard',        'match' => 'koor.dashboard',             'icon' => $iHome],
                ],
                'Pendaftaran' => [
                    ['href' => route('eoffice.manprak.koor.pendaftaran-asprak.index'), 'label' => 'Seleksi Asprak',   'match' => 'koor.pendaftaran-asprak',    'icon' => $iCheck],
                ],
                'Kelola' => [
                    ['href' => route('eoffice.manprak.koor.modul.index'),              'label' => 'Kelola Modul',     'match' => 'koor.modul',                 'icon' => $iBook],
                    ['href' => route('eoffice.manprak.koor.bagi-modul.index'),         'label' => 'Bagi Modul',       'match' => 'bagi-modul',                 'icon' => $iGear],
                    ['href' => route('eoffice.manprak.koor.praktikan.index'),          'label' => 'Data Praktikan',   'match' => 'koor.praktikan',             'icon' => $iUser],
                    ['href' => route('eoffice.manprak.koor.pengumuman.index'),         'label' => 'Pengumuman',       'match' => 'koor.pengumuman',            'icon' => $iBell],
                    ['href' => route('eoffice.manprak.koor.nilai.index'),              'label' => 'Absensi & Nilai',  'match' => 'koor.nilai',                 'icon' => $iCheck],
                ],
            ],
        ];
    }

    if ($isAsprak) {
        $sections[] = [
            'label' => 'Asprak',
            'color' => '#40C4AA',
            'bg'    => 'rgba(64,196,170,0.10)',
            'match' => 'manprak.asprak',
            'groups' => [
                'Utama' => [
                    ['href' => route('eoffice.manprak.asprak.dashboard'),          'label' => 'Dashboard',   'match' => 'asprak.dashboard',  'icon' => $iHome],
                ],
                'Aktivitas' => [
                    ['href' => route('eoffice.manprak.asprak.absensi.index'),      'label' => 'Absensi',     'match' => 'asprak.absensi',     'icon' => $iCheck],
                    ['href' => route('eoffice.manprak.asprak.tugas.index'),        'label' => 'Tugas',       'match' => 'asprak.tugas',       'icon' => $iEdit],
                    ['href' => route('eoffice.manprak.asprak.materi.index'),       'label' => 'Materi',      'match' => 'asprak.materi',      'icon' => $iBook],
                    ['href' => route('eoffice.manprak.asprak.pengumuman.index'),   'label' => 'Pengumuman',  'match' => 'asprak.pengumuman',  'icon' => $iBell],
                ],
            ],
        ];
    }

    // Mahasiswa — selalu muncul
    $sections[] = [
        'label' => 'Mahasiswa',
        'color' => '#D39C3D',
        'bg'    => 'rgba(211,156,61,0.10)',
        'match' => 'manprak.mahasiswa',
        'groups' => [
            'Utama' => [
                ['href' => route('eoffice.manprak.mahasiswa.dashboard'),            'label' => 'Dashboard',         'match' => 'mahasiswa.dashboard',  'icon' => $iHome],
            ],
            'Aktivitas' => [
                ['href' => route('eoffice.manprak.mahasiswa.pengumuman.index'),     'label' => 'Pengumuman',        'match' => 'mahasiswa.pengumuman', 'icon' => $iBell],
                ['href' => route('eoffice.manprak.mahasiswa.tugas.index'),          'label' => 'Tugas',             'match' => 'mahasiswa.tugas',      'icon' => $iEdit],
                ['href' => route('eoffice.manprak.mahasiswa.nilai.index'),          'label' => 'Nilai',             'match' => 'mahasiswa.nilai',      'icon' => $iCheck],
                ['href' => route('eoffice.manprak.mahasiswa.daftar-asprak.index'), 'label' => 'Daftar Asprak/Koor','match' => 'daftar-asprak',        'icon' => $iUser],
            ],
        ],
    ];

    $multiRole    = count($sections) > 1;
    $manprakActive= str_contains($currentRoute, 'manprak');
    $notifCount   = \Modules\EOffice\Models\Notifikasi::where('user_id', $user->id)->where('is_read', false)->count();
@endphp

<div class="flex h-screen overflow-hidden" x-data="{ sidebarOpen: localStorage.getItem('mp_sb') !== '0' }"
     x-init="$watch('sidebarOpen', v => localStorage.setItem('mp_sb', v ? '1' : '0'))">

    {{-- ═══════════════════════════════════════════════════════════════ --}}
    {{-- SIDEBAR                                                        --}}
    {{-- ═══════════════════════════════════════════════════════════════ --}}
    <aside class="flex flex-col flex-shrink-0 bg-white border-r border-[#DFE1E7] relative overflow-visible z-20 transition-all duration-[240ms] ease-[cubic-bezier(.4,0,.2,1)]"
           :class="sidebarOpen ? 'w-[240px]' : 'w-[64px]'">

        {{-- Brand --}}
        <div class="relative px-[10px] pt-[18px] pb-[10px]">
            <div class="flex items-center gap-[10px] px-[10px] py-2 rounded-[10px]">
                <div class="flex items-center justify-center w-[34px] h-[34px] rounded-[9px] flex-shrink-0 bg-white shadow-sm overflow-hidden">
                    <img src="{{ asset('images/UNDIPOfficial.png') }}" alt="UNDIP" class="w-[24px] h-[24px] object-contain">
                </div>
                <div class="flex-1 min-w-0 overflow-hidden transition-[opacity,width] duration-200" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0'">
                    <div class="font-bold text-[13px] text-[#0D0D12] leading-[1.2] whitespace-nowrap">SIPERKOM</div>
                    <div class="text-[9px] font-semibold text-[#A4ABB8] uppercase tracking-[.04em] whitespace-nowrap">Man. Praktikum</div>
                </div>
            </div>
            <button @click="sidebarOpen = !sidebarOpen"
                    class="absolute right-[-12px] top-[34px] flex items-center justify-center w-6 h-6 rounded-full bg-white border border-[#DFE1E7] shadow-[0_1px_4px_rgba(0,0,0,.08)] cursor-pointer z-30 hover:bg-[#F6F8FA]">
                <svg class="transition-transform duration-[240ms]" :class="sidebarOpen ? '' : 'rotate-180'"
                     width="8" height="8" viewBox="0 0 10 10" fill="none" stroke="#666D80" stroke-width="2.2" stroke-linecap="round">
                    <path d="M7 1L3 5L7 9"/>
                </svg>
            </button>
        </div>

        {{-- Role badges (multi-role indicator, collapsed = dot only) --}}
        @if($multiRole)
        <div class="px-[10px] pb-[6px] flex flex-wrap gap-[3px] overflow-hidden transition-opacity duration-200"
             :class="sidebarOpen ? 'opacity-100 px-[20px]' : 'opacity-0 h-0 pointer-events-none'">
            @if($isAdmin)  <span class="text-[9px] font-bold px-[6px] py-[1px] rounded-full text-white whitespace-nowrap" style="background:#DF1C41;">ADMIN</span>  @endif
            @if($isDosen)  <span class="text-[9px] font-bold px-[6px] py-[1px] rounded-full text-white whitespace-nowrap" style="background:#0B266E;">DOSEN</span>  @endif
            @if($isKoor)   <span class="text-[9px] font-bold px-[6px] py-[1px] rounded-full text-white whitespace-nowrap" style="background:#6366F1;">KOOR</span>   @endif
            @if($isAsprak) <span class="text-[9px] font-bold px-[6px] py-[1px] rounded-full text-white whitespace-nowrap" style="background:#40C4AA;">ASPRAK</span> @endif
            <span class="text-[9px] font-bold px-[6px] py-[1px] rounded-full text-white whitespace-nowrap" style="background:#D39C3D;">MHS</span>
        </div>
        @endif

        {{-- Nav --}}
        <nav class="flex-1 overflow-y-auto overflow-x-hidden px-[10px] py-1 flex flex-col [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">

            @foreach($sections as $section)
            @php
                $sectionColor  = $section['color'];
                $sectionBg     = $section['bg'];
                $sectionActive = str_contains($currentRoute, $section['match']);
            @endphp

            {{-- Section wrapper: multi-role = collapsible header, single = langsung tampil --}}
            <div x-data="{ openSec: {{ ($sectionActive || !$multiRole) ? 'true' : 'false' }} }"
                 class="mb-[2px]">

                @if($multiRole)
                {{-- Collapsible section header --}}
                <button @click="if(sidebarOpen) openSec = !openSec; else { sidebarOpen = true; openSec = true; }"
                        class="w-full flex items-center gap-[8px] px-[10px] py-[6px] rounded-[8px] border-none cursor-pointer text-left mb-[2px] transition-colors"
                        :class="sidebarOpen ? '' : 'justify-center'"
                        :style="openSec ? 'background:{{ $sectionBg }}' : 'background:transparent'"
                        style="background:transparent">
                    {{-- Color dot --}}
                    <span class="w-[7px] h-[7px] rounded-full flex-shrink-0"
                          style="background:{{ $sectionColor }}"></span>
                    <span class="text-[11px] font-bold tracking-[.04em] flex-1 overflow-hidden text-ellipsis whitespace-nowrap transition-[opacity,width] duration-200"
                          :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0'"
                          style="color:{{ $sectionColor }}">{{ strtoupper($section['label']) }}</span>
                    <svg class="w-[9px] h-[9px] flex-shrink-0 transition-transform duration-150"
                         :class="[sidebarOpen ? 'opacity-100' : 'opacity-0 w-0', openSec ? 'rotate-180' : '']"
                         viewBox="0 0 24 24" fill="none" stroke="{{ $sectionColor }}" stroke-width="2.5" stroke-linecap="round">
                        <polyline points="6 9 12 15 18 9"/>
                    </svg>
                </button>
                @endif

                {{-- Section groups & items --}}
                <div @if($multiRole) x-show="openSec || !sidebarOpen"
                     x-transition:enter="transition ease-out duration-150"
                     x-transition:enter-start="opacity-0 -translate-y-1"
                     x-transition:enter-end="opacity-100 translate-y-0"
                     x-transition:leave="transition ease-in duration-100"
                     x-transition:leave-end="opacity-0" @endif
                     @if($multiRole) class="pl-[8px] border-l-2 ml-[12px] mb-[4px]"
                     style="border-color:{{ $sectionColor }}30" @endif>

                    @foreach($section['groups'] as $groupLabel => $items)

                    {{-- Group label --}}
                    <div class="text-[10px] font-semibold text-[#A4ABB8] uppercase tracking-[.06em] px-[10px] pt-[6px] pb-[2px] whitespace-nowrap overflow-hidden transition-opacity duration-200"
                         :class="sidebarOpen ? 'opacity-100' : 'opacity-0'">{{ $groupLabel }}</div>

                    @foreach($items as $item)
                    @php $active = str_contains($currentRoute, $item['match']); @endphp
                    <a href="{{ $item['href'] }}"
                       class="flex items-center gap-[10px] px-[10px] py-[8px] rounded-[8px] mb-[1px] no-underline transition-colors duration-[120ms] overflow-hidden whitespace-nowrap"
                       :class="sidebarOpen ? '' : 'justify-center'"
                       @if($active)
                           style="background:{{ $sectionColor }}; color:white;"
                       @else
                           style="color:#353849"
                           onmouseover="this.style.background='#F6F8FA'"
                           onmouseout="this.style.background='transparent'"
                       @endif>
                        <svg class="w-[14px] h-[14px] flex-shrink-0"
                             style="color:{{ $active ? 'white' : '#666D80' }}"
                             viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                            <path d="{{ $item['icon'] }}"/>
                        </svg>
                        <span class="text-[12px] flex-1 overflow-hidden text-ellipsis transition-[opacity,width] duration-200
                                     {{ $active ? 'font-semibold' : 'font-medium' }}"
                              :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0'">{{ $item['label'] }}</span>
                    </a>
                    @endforeach
                    @endforeach

                </div>
            </div>

            {{-- Divider antara sections --}}
            @if(!$loop->last)
            <div class="h-px bg-[#F0F1F4] mx-[6px] my-[4px]"></div>
            @endif

            @endforeach

            {{-- Kembali ke EOffice --}}
            <div class="h-px bg-[#F0F1F4] mx-[14px] my-[6px]"></div>
            <a href="{{ route('eoffice.dashboard') }}"
               class="flex items-center gap-[10px] px-[10px] py-[9px] rounded-lg no-underline transition-colors hover:bg-[#F6F8FA] text-[#666D80]"
               :class="sidebarOpen ? '' : 'justify-center'">
                <svg class="w-[14px] h-[14px] flex-shrink-0 text-[#A4ABB8]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
                    <path d="{{ $iBack }}"/>
                </svg>
                <span class="text-[12px] font-medium flex-1 transition-[opacity,width] duration-200"
                      :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0'">Kembali ke EOffice</span>
            </a>
        </nav>

        {{-- User footer --}}
        <div class="px-3 py-[10px] border-t border-[#DFE1E7] flex-shrink-0">
            <div class="flex items-center gap-[10px] px-[10px] py-2 rounded-lg overflow-hidden transition-colors hover:bg-[#F6F8FA]">
                @if($user->avatar_url)
                <img src="{{ $user->avatar_url }}" alt="{{ $name }}"
                     class="w-[30px] h-[30px] rounded-full object-cover flex-shrink-0">
                @else
                <div class="flex items-center justify-center w-[30px] h-[30px] rounded-full flex-shrink-0 text-white text-[11px] font-bold"
                     style="background:linear-gradient(135deg,#3C518B,#0B266E);">{{ $initials }}</div>
                @endif
                <div class="flex-1 min-w-0 overflow-hidden transition-[opacity,width] duration-200" :class="sidebarOpen ? 'opacity-100' : 'opacity-0 w-0'">
                    <div class="text-[12px] font-semibold text-[#0D0D12] whitespace-nowrap overflow-hidden text-ellipsis leading-[1.2]">{{ $name }}</div>
                    <div class="text-[10px] text-[#666D80] whitespace-nowrap overflow-hidden text-ellipsis">{{ $user->email }}</div>
                </div>
                <form method="POST" action="{{ route('logout') }}" class="flex-shrink-0"
                      :class="sidebarOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'">
                    @csrf
                    <button type="submit" class="p-1 rounded text-[#A4ABB8] hover:text-red-500 bg-transparent border-none cursor-pointer">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
                            <path d="{{ $iLogout }}"/>
                        </svg>
                    </button>
                </form>
            </div>
        </div>
    </aside>

    {{-- ═══════════════════════════════════════════════════════════════ --}}
    {{-- MAIN AREA                                                      --}}
    {{-- ═══════════════════════════════════════════════════════════════ --}}
    <div class="flex-1 flex flex-col overflow-hidden">

        {{-- Topbar --}}
        <div class="flex items-center justify-between px-6 bg-white border-b border-[#DFE1E7] flex-shrink-0" style="height:56px;">
            <div class="flex items-center gap-3 min-w-0">
                <div>
                    <div class="font-bold text-[15px] text-[#0D0D12] leading-[1.2]">{{ $pageTitle ?? 'Dashboard' }}</div>
                    <div class="text-[11px] text-[#666D80]">Manajemen Praktikum · SIPERKOM</div>
                </div>
            </div>
            <div class="flex items-center gap-2">
                <div class="relative flex items-center justify-center w-[34px] h-[34px] rounded-lg border border-[#DFE1E7] bg-white cursor-pointer hover:bg-[#F6F8FA]">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#666D80" stroke-width="1.8" stroke-linecap="round">
                        <path d="{{ $iBell }}"/>
                    </svg>
                    @if($notifCount > 0)
                    <span class="absolute top-[6px] right-[6px] w-[6px] h-[6px] rounded-full bg-[#DF1C41] border-[1.5px] border-white"></span>
                    @endif
                </div>
            </div>
        </div>

        {{-- Flash alerts --}}
        @if(session('success'))
        <div class="mx-6 mt-3 flex items-center gap-2 bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] px-4 py-[10px] text-[13px] font-medium text-[#174E43] flex-shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            {{ session('success') }}
        </div>
        @endif
        @if(session('error'))
        <div class="mx-6 mt-3 flex items-center gap-2 bg-[#FADAE1] border border-[#DF1C41] rounded-[10px] px-4 py-[10px] text-[13px] font-medium text-[#7C1028] flex-shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            {{ session('error') }}
        </div>
        @endif

        {{-- Page Content --}}
        <div class="flex-1 overflow-y-auto p-6 flex flex-col gap-[18px]">
            {{ $slot }}
        </div>
    </div>
</div>
</body>
</html>
