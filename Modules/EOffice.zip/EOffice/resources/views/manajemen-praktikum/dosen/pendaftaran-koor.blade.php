<x-eoffice::manajemen-praktikum.layout pageTitle="Seleksi Koordinator">

<div>
    <div class="text-[20px] font-bold text-[#0D0D12]">Seleksi Koordinator Praktikum</div>
    <div class="text-[12px] text-[#666D80] mt-[2px]">Review pendaftar koor sesuai praktikum yang Anda ampu</div>
</div>

<div class="bg-[#EEF2FF] border border-[#C7D2FE] rounded-[10px] px-4 py-3 text-[12px] text-[#0B266E]">
    <strong>Alur:</strong> Anda mereview data mahasiswa (IPK, motivasi) → Setujui/Tolak → Jika disetujui, masuk ke antrian Admin untuk final approval.
</div>

@if(session('success'))
<div class="bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] px-4 py-3 text-[13px] text-[#174E43]">{{ session('success') }}</div>
@endif

{{-- Filter --}}
<div class="flex gap-2 flex-wrap">
    <form method="GET" class="flex gap-2 flex-wrap">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari nama..."
               class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E] w-[180px]">
        <select name="praktikum_id" class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            <option value="">Semua Praktikum</option>
            @foreach($praktikumList as $pr)
            <option value="{{ $pr->id }}" {{ request('praktikum_id') == $pr->id ? 'selected' : '' }}>{{ $pr->nama }}</option>
            @endforeach
        </select>
        <select name="status_dosen" class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            <option value="">Semua Status</option>
            <option value="menunggu"  {{ request('status_dosen')=='menunggu'  ? 'selected' : '' }}>Menunggu Review</option>
            <option value="disetujui" {{ request('status_dosen')=='disetujui' ? 'selected' : '' }}>Sudah Disetujui</option>
            <option value="ditolak"   {{ request('status_dosen')=='ditolak'   ? 'selected' : '' }}>Ditolak</option>
        </select>
        <button type="submit" class="px-4 py-[8px] rounded-[8px] bg-[#0B266E] text-white text-[13px] font-semibold border-none cursor-pointer">Filter</button>
    </form>
</div>

<div class="bg-white border border-[#DFE1E7] rounded-[14px] overflow-hidden shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <div class="overflow-x-auto">
        <table class="w-full text-[13px]">
            <thead class="bg-[#FAFBFC] border-b border-[#DFE1E7]">
                <tr>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Mahasiswa</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Praktikum</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">IPK</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Motivasi</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Status</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($pendaftaran as $p)
                <tr class="border-b border-[#F8F9FB] hover:bg-[#FAFAFC]">
                    <td class="py-3 px-4">
                        <div class="font-semibold text-[#0D0D12]">{{ $p->user?->name ?? '—' }}</div>
                        <div class="text-[11px] text-[#666D80]">{{ $p->user?->email }}</div>
                    </td>
                    <td class="py-3 px-4 text-[#353849]">{{ $p->praktikum?->nama ?? '—' }}</td>
                    <td class="py-3 px-4 font-bold text-[{{ ($p->ipk ?? 0) >= 3.0 ? '#40C4AA' : '#DF1C41' }}]">
                        {{ number_format($p->ipk ?? 0, 2) }}
                    </td>
                    <td class="py-3 px-4 text-[#666D80] max-w-[200px]">
                        <div class="line-clamp-2 text-[12px]">{{ $p->motivasi ?? '—' }}</div>
                    </td>
                    <td class="py-3 px-4">
                        @if($p->status_dosen === 'disetujui')
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">Disetujui</span>
                        <div class="text-[10px] text-[#666D80] mt-[2px]">Menunggu Admin</div>
                        @elseif($p->status_dosen === 'ditolak')
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#FADAE1] text-[#7C1028]">Ditolak</span>
                        @else
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#F9ECCB] text-[#7C5309]">Menunggu Review</span>
                        @endif
                    </td>
                    <td class="py-3 px-4">
                        @if($p->status_dosen === 'menunggu')
                        <div class="flex gap-2" x-data="{ catatan: '' }">
                            <form method="POST" action="{{ route('eoffice.manprak.dosen.pendaftaran-koor.approve', $p->id) }}">
                                @csrf
                                <input type="hidden" name="catatan_dosen" value="">
                                <button type="submit"
                                        class="text-[12px] font-semibold px-3 py-[5px] rounded-[7px] bg-[#DDF2EE] text-[#174E43] border-none cursor-pointer hover:bg-[#c0e8e0]">
                                    Setujui
                                </button>
                            </form>
                            <form method="POST" action="{{ route('eoffice.manprak.dosen.pendaftaran-koor.reject', $p->id) }}" x-data="{ alasan: '' }">
                                @csrf
                                <input type="hidden" name="alasan_penolakan" :value="alasan">
                                <button type="button"
                                        @click="alasan = prompt('Alasan penolakan:'); if(alasan !== null) $el.closest('form').submit()"
                                        class="text-[12px] font-semibold px-3 py-[5px] rounded-[7px] bg-[#FADAE1] text-[#7C1028] border-none cursor-pointer hover:bg-[#f5c0cc]">
                                    Tolak
                                </button>
                            </form>
                        </div>
                        @else
                        <span class="text-[11px] text-[#A4ABB8]">Sudah diproses</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="py-10 text-center text-[13px] text-[#A4ABB8]">Tidak ada pendaftaran untuk praktikum Anda.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($pendaftaran->hasPages())
    <div class="px-4 py-3 border-t border-[#DFE1E7]">{{ $pendaftaran->links() }}</div>
    @endif
</div>

</x-eoffice::manajemen-praktikum.layout>
