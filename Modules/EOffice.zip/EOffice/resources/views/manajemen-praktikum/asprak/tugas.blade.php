<x-eoffice::manajemen-praktikum.layout pageTitle="Kelola Tugas">

<div class="flex items-center justify-between flex-shrink-0">
    <div>
        <div class="text-[20px] font-bold text-[#0D0D12]">Kelola Tugas Praktikum</div>
        <div class="text-[12px] text-[#666D80] mt-[2px]">Buat tugas dan nilai pengumpulan mahasiswa</div>
    </div>
    <a href="{{ route('eoffice.manprak.asprak.tugas.create') }}"
       class="flex items-center gap-2 px-4 py-[9px] rounded-[9px] bg-[#40C4AA] text-white text-[13px] font-semibold no-underline hover:bg-[#32a896]">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Buat Tugas Baru
    </a>
</div>

@forelse($tugasList ?? [] as $tugas)
@php
    $dl    = $tugas->deadline ? \Carbon\Carbon::parse($tugas->deadline) : null;
    $lewat = $dl && now()->gt($dl);
    $totalKumpul = $tugas->pengumpulan_count ?? 0;
    $acc         = $tugas->pengumpulan_acc_count ?? 0;
    $revisi      = $tugas->pengumpulan_revisi_count ?? 0;
    $belumDicek  = $totalKumpul - $acc - $revisi;
@endphp
<div class="bg-white border border-[#DFE1E7] rounded-[14px] p-5 shadow-[0_1px_2px_rgba(228,229,231,.24)]" x-data="{ open: false }">
    <div class="flex items-center justify-between">
        <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2 mb-1 flex-wrap">
                <div class="text-[14px] font-bold text-[#0D0D12]">{{ $tugas->judul }}</div>
                @if($lewat)
                <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#F0F1F4] text-[#666D80]">Berakhir</span>
                @else
                <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">Aktif</span>
                @endif
            </div>
            <div class="text-[12px] text-[#666D80]">
                Modul: <span class="font-semibold text-[#353849]">{{ $tugas->modul?->nama ?? '—' }}</span>
                @if($dl)
                · Deadline: <span class="font-semibold {{ $lewat ? 'text-[#666D80]' : 'text-[#353849]' }}">{{ $dl->format('d M Y, H:i') }}</span>
                @endif
            </div>
        </div>
        <div class="flex items-center gap-4 flex-shrink-0">
            {{-- Stat boxes --}}
            <div class="text-center">
                <div class="text-[16px] font-bold text-[#0D0D12]">{{ $totalKumpul }}</div>
                <div class="text-[10px] text-[#666D80]">Dikumpul</div>
            </div>
            <div class="text-center">
                <div class="text-[16px] font-bold text-[#D39C3D]">{{ max(0,$belumDicek) }}</div>
                <div class="text-[10px] text-[#666D80]">Belum Dicek</div>
            </div>
            <div class="text-center">
                <div class="text-[16px] font-bold text-[#DF1C41]">{{ $revisi }}</div>
                <div class="text-[10px] text-[#666D80]">Revisi</div>
            </div>
            <div class="text-center">
                <div class="text-[16px] font-bold text-[#40C4AA]">{{ $acc }}</div>
                <div class="text-[10px] text-[#666D80]">ACC</div>
            </div>
            <button @click="open = !open"
                    class="text-[12px] font-semibold px-4 py-[7px] rounded-[8px] border border-[#DFE1E7] text-[#353849] bg-white cursor-pointer hover:bg-[#F6F8FA]"
                    x-text="open ? 'Tutup' : 'Lihat Pengumpulan'">
            </button>
        </div>
    </div>

    {{-- Pengumpulan Table --}}
    <div x-show="open" x-transition class="mt-4 border-t border-[#F0F1F4] pt-4">
        @php $pengumpulanList = $tugas->pengumpulan ?? collect(); @endphp
        @if($pengumpulanList->isEmpty())
        <div class="py-5 text-center text-[13px] text-[#A4ABB8]">Belum ada yang mengumpulkan.</div>
        @else
        <div class="rounded-[10px] border border-[#DFE1E7] overflow-hidden">
            <div class="flex px-4 py-[8px] bg-[#FAFBFC] border-b border-[#DFE1E7]">
                <div class="flex-1 text-[11px] font-semibold text-[#666D80] uppercase tracking-wider">Mahasiswa</div>
                <div class="text-[11px] font-semibold text-[#666D80] uppercase tracking-wider" style="width:90px;">Status</div>
                <div class="text-[11px] font-semibold text-[#666D80] uppercase tracking-wider" style="width:100px;">Waktu Kumpul</div>
                <div class="text-[11px] font-semibold text-[#666D80] uppercase tracking-wider" style="width:65px;">File</div>
                <div class="text-[11px] font-semibold text-[#666D80] uppercase tracking-wider" style="width:65px;">Nilai</div>
                <div class="text-[11px] font-semibold text-[#666D80] uppercase tracking-wider" style="width:200px;">Aksi</div>
            </div>
            @foreach($pengumpulanList as $peng)
            @php
                $st = $peng->status_pengumpulan ?? 'belum_dicek';
            @endphp
            <div class="flex items-center px-4 py-[10px] border-b border-[#F8F9FB] last:border-0 hover:bg-[#FAFAFC]">
                <div class="flex-1 flex items-center gap-2 min-w-0 pr-2">
                    <div class="text-[13px] font-medium text-[#0D0D12] truncate">{{ $peng->daftarPraktikan?->user?->name ?? '—' }}</div>
                    @if($peng->is_revision)
                    <span class="text-[10px] bg-[#EEF2FF] text-[#0B266E] px-1 rounded font-semibold">Revisi ke-{{ $peng->is_revision }}</span>
                    @endif
                </div>
                {{-- Status badge --}}
                <div style="width:90px;">
                    @if($st === 'acc')
                    <span class="text-[10px] font-semibold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">ACC</span>
                    @elseif($st === 'revisi')
                    <span class="text-[10px] font-semibold px-2 py-[2px] rounded-full bg-[#FADAE1] text-[#7C1028]">Revisi</span>
                    @else
                    <span class="text-[10px] font-semibold px-2 py-[2px] rounded-full bg-[#F9ECCB] text-[#7C5309]">Belum Dicek</span>
                    @endif
                </div>
                <div class="text-[11px] text-[#666D80]" style="width:100px;">{{ $peng->created_at?->format('d M, H:i') }}</div>
                <div style="width:65px;">
                    @if($peng->file_path)
                    <a href="{{ Storage::url($peng->file_path) }}" target="_blank"
                       class="text-[11px] font-semibold text-[#0B266E] no-underline hover:underline">Unduh</a>
                    @else
                    <span class="text-[11px] text-[#A4ABB8]">—</span>
                    @endif
                </div>
                <div style="width:65px;">
                    @if($peng->nilai !== null)
                    <span class="text-[14px] font-bold" style="color:{{ $peng->nilai >= 75 ? '#40C4AA' : ($peng->nilai >= 50 ? '#D39C3D' : '#DF1C41') }};">{{ $peng->nilai }}</span>
                    @else
                    <span class="text-[12px] text-[#A4ABB8]">—</span>
                    @endif
                </div>
                {{-- Aksi: input nilai (ACC) + tombol revisi --}}
                <div class="flex gap-1 items-center" style="width:200px;">
                    @if($st !== 'acc')
                    <form method="POST" action="{{ route('eoffice.manprak.asprak.tugas.nilai', $peng->id) }}" class="flex gap-1 items-center">
                        @csrf
                        <input type="number" name="nilai" min="0" max="100" step="1" placeholder="0–100"
                               value="{{ $peng->nilai ?? '' }}"
                               class="w-[68px] border border-[#DFE1E7] rounded-[6px] px-2 py-[4px] text-[12px] focus:outline-none focus:border-[#40C4AA]">
                        <button type="submit"
                                class="text-[11px] font-semibold px-2 py-[4px] rounded-[6px] bg-[#DDF2EE] text-[#174E43] border-none cursor-pointer hover:bg-[#c0e8e0]">ACC</button>
                    </form>
                    @endif
                    @if($st !== 'revisi' && $st !== 'acc')
                    <form method="POST" action="{{ route('eoffice.manprak.asprak.tugas.revisi', $peng->id) }}" x-data="{ catatan: '' }">
                        @csrf
                        <input type="hidden" name="catatan_revisi" :value="catatan">
                        <button type="button"
                                @click="catatan = prompt('Catatan revisi:'); if(catatan) $el.closest('form').submit()"
                                class="text-[11px] font-semibold px-2 py-[4px] rounded-[6px] bg-[#F9ECCB] text-[#7C5309] border-none cursor-pointer hover:bg-[#f0e0b0]">Revisi</button>
                    </form>
                    @endif
                    @if($st === 'acc')
                    <span class="text-[11px] text-[#40C4AA] font-semibold">✓ Selesai</span>
                    @endif
                </div>
            </div>
            @endforeach
        </div>
        @endif
    </div>
</div>
@empty
<div class="flex-1 bg-white border border-[#DFE1E7] rounded-[14px] flex items-center justify-center min-h-[200px]">
    <div class="text-center text-[#A4ABB8]">
        <svg class="mx-auto mb-3 w-10 h-10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
        <div class="text-[14px] font-medium">Belum ada tugas. Buat tugas baru!</div>
    </div>
</div>
@endforelse

</x-eoffice::manajemen-praktikum.layout>
