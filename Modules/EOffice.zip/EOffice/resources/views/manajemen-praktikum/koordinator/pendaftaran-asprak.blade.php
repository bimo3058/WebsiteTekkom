<x-eoffice::manajemen-praktikum.layout pageTitle="Seleksi Asprak">

<div>
    <div class="text-[20px] font-bold text-[#0D0D12]">Seleksi Asisten Praktikum</div>
    <div class="text-[12px] text-[#666D80] mt-[2px]">Review dan seleksi calon asprak untuk praktikum yang Anda koordinatori</div>
</div>

@if($periodeAktif)
<div class="bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] px-4 py-3 text-[12px] text-[#174E43]">
    <strong>● Pendaftaran Sedang Buka:</strong> {{ $periodeAktif->nama }}
    @if($periodeAktif->ditutup_pada)
    · Ditutup: {{ $periodeAktif->ditutup_pada->format('d M Y H:i') }}
    @endif
</div>
@else
<div class="bg-[#F9ECCB] border border-[#D39C3D] rounded-[10px] px-4 py-3 text-[12px] text-[#7C5309]">
    <strong>⏸ Periode pendaftaran sedang tutup.</strong> Hubungi Admin untuk membuka periode pendaftaran baru.
</div>
@endif

<div class="bg-[#EEF2FF] border border-[#C7D2FE] rounded-[10px] px-4 py-3 text-[12px] text-[#0B266E]">
    <strong>Alur:</strong> Mahasiswa mendaftar → Anda review (IPK, motivasi, transkrip) → Approve → Role <code>asprak</code> di-assign otomatis sesuai praktikum Anda.
</div>

@if(session('success'))
<div class="bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] px-4 py-3 text-[13px] text-[#174E43]">{{ session('success') }}</div>
@endif

{{-- Filter --}}
<div class="flex gap-2 flex-wrap">
    <form method="GET" class="flex gap-2 flex-wrap">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari nama..."
               class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#6366F1] w-[180px]">
        <select name="status" class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#6366F1]">
            <option value="">Semua Status</option>
            <option value="pending"  {{ request('status')=='pending'  ? 'selected' : '' }}>Pending</option>
            <option value="approved" {{ request('status')=='approved' ? 'selected' : '' }}>Diterima</option>
            <option value="rejected" {{ request('status')=='rejected' ? 'selected' : '' }}>Ditolak</option>
        </select>
        <button type="submit" class="px-4 py-[8px] rounded-[8px] text-white text-[13px] font-semibold border-none cursor-pointer"
                style="background:#6366F1">Filter</button>
    </form>
</div>

<div class="bg-white border border-[#DFE1E7] rounded-[14px] overflow-hidden shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <div class="overflow-x-auto">
        <table class="w-full text-[13px]">
            <thead class="bg-[#FAFBFC] border-b border-[#DFE1E7]">
                <tr>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Mahasiswa</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">IPK</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Motivasi</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">CV / Transkrip</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Jadwal</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Status</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($pendaftaran as $p)
                <tr class="border-b border-[#F8F9FB] hover:bg-[#FAFAFC]">
                    <td class="py-3 px-4">
                        <div class="font-semibold text-[#0D0D12]">{{ $p->user?->name ?? '—' }}</div>
                        <div class="text-[11px] text-[#666D80]">{{ $p->user?->email }}</div>
                        <div class="text-[10px] text-[#A4ABB8]">{{ $p->created_at?->format('d M Y') }}</div>
                    </td>
                    <td class="py-3 px-4 font-bold" style="color: {{ ($p->ipk ?? 0) >= 3.0 ? '#40C4AA' : '#DF1C41' }}">
                        {{ number_format($p->ipk ?? 0, 2) }}
                    </td>
                    <td class="py-3 px-4 text-[#666D80] max-w-[180px]">
                        <div class="line-clamp-2 text-[12px]">{{ $p->motivasi ?? '—' }}</div>
                    </td>
                    <td class="py-3 px-4">
                        @if($p->cv_path)
                        <a href="{{ Storage::url($p->cv_path) }}" target="_blank"
                           class="text-[11px] font-semibold text-[#6366F1] no-underline hover:underline block">CV</a>
                        @endif
                        @if($p->transkrip_path)
                        <a href="{{ Storage::url($p->transkrip_path) }}" target="_blank"
                           class="text-[11px] font-semibold text-[#0B266E] no-underline hover:underline block">Transkrip</a>
                        @endif
                        @if(!$p->cv_path && !$p->transkrip_path)
                        <span class="text-[11px] text-[#A4ABB8]">—</span>
                        @endif
                    </td>
                    <td class="py-3 px-4 text-[11px] text-[#666D80]">
                        {{ collect($p->jadwal ?? [])->join(', ') ?: '—' }}
                    </td>
                    <td class="py-3 px-4">
                        @if($p->status === 'approved')
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">✓ Diterima</span>
                        <div class="text-[10px] text-[#666D80] mt-[2px]">Role asprak aktif</div>
                        @elseif($p->status === 'rejected')
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#FADAE1] text-[#7C1028]">✗ Ditolak</span>
                        @else
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#F9ECCB] text-[#7C5309]">⏳ Pending</span>
                        @endif
                    </td>
                    <td class="py-3 px-4">
                        @if($p->status === 'pending')
                        <div class="flex gap-2">
                            <form method="POST" action="{{ route('eoffice.manprak.koor.pendaftaran-asprak.approve', $p->id) }}">
                                @csrf
                                <button type="submit"
                                        class="text-[12px] font-semibold px-3 py-[5px] rounded-[7px] bg-[#DDF2EE] text-[#174E43] border-none cursor-pointer hover:bg-[#c0e8e0]">
                                    Terima
                                </button>
                            </form>
                            <form method="POST" action="{{ route('eoffice.manprak.koor.pendaftaran-asprak.reject', $p->id) }}" x-data="{ alasan: '' }">
                                @csrf
                                <input type="hidden" name="alasan_penolakan" :value="alasan">
                                <button type="button"
                                        @click="alasan = prompt('Alasan penolakan:'); if(alasan !== null) $el.closest('form').submit()"
                                        class="text-[12px] font-semibold px-3 py-[5px] rounded-[7px] bg-[#FADAE1] text-[#7C1028] border-none cursor-pointer hover:bg-[#f5c0cc]">
                                    Tolak
                                </button>
                            </form>
                        </div>
                        @else
                        <span class="text-[11px] text-[#A4ABB8]">Sudah diproses</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" class="py-10 text-center text-[13px] text-[#A4ABB8]">Belum ada pendaftar asprak.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($pendaftaran->hasPages())
    <div class="px-4 py-3 border-t border-[#DFE1E7]">{{ $pendaftaran->links() }}</div>
    @endif
</div>

</x-eoffice::manajemen-praktikum.layout>
