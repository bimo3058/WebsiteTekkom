<x-eoffice::manajemen-praktikum.layout pageTitle="Pendaftaran Asprak & Koordinator">

<div>
    <div class="text-[20px] font-bold text-[#0D0D12]">Pendaftaran Asprak & Koordinator</div>
    <div class="text-[12px] text-[#666D80] mt-[2px]">Daftarkan diri sebagai calon asisten atau koordinator praktikum</div>
</div>

@if(session('success'))
<div class="bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] px-4 py-3 text-[13px] text-[#174E43] flex items-center gap-2">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
    {{ session('success') }}
</div>
@endif
@if(session('error'))
<div class="bg-[#FADAE1] border border-[#DF1C41] rounded-[10px] px-4 py-3 text-[13px] text-[#7C1028] flex items-center gap-2">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    {{ session('error') }}
</div>
@endif

{{-- Badge role aktif --}}
@if($sudahJadiAsprak || $sudahJadiKoor)
<div class="flex gap-2 flex-wrap">
    @if($sudahJadiAsprak)
    <div class="flex items-center gap-2 px-4 py-2 bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] text-[12px] text-[#174E43] font-semibold">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
        Anda aktif sebagai Asisten Praktikum
    </div>
    @endif
    @if($sudahJadiKoor)
    <div class="flex items-center gap-2 px-4 py-2 bg-[#EEF2FF] border border-[#818CF8] rounded-[10px] text-[12px] text-[#0B266E] font-semibold">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
        Anda aktif sebagai Koordinator Praktikum
    </div>
    @endif
</div>
@endif

{{-- Tidak ada periode terbuka sama sekali --}}
@if($praktikumDenganPeriode->isEmpty())
<div class="bg-white border border-[#DFE1E7] rounded-[14px] py-14 text-center shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <svg class="mx-auto mb-3 w-10 h-10 text-[#DFE1E7]" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    </svg>
    <div class="text-[14px] font-semibold text-[#0D0D12]">Belum ada pendaftaran yang dibuka</div>
    <div class="text-[12px] text-[#666D80] mt-1">Admin belum membuka periode pendaftaran asprak atau koordinator saat ini.</div>
    <div class="text-[12px] text-[#A4ABB8] mt-3">Pantau terus halaman ini atau tunggu notifikasi dari sistem.</div>
</div>

@else

{{-- Card per praktikum yang punya periode terbuka --}}
@foreach($praktikumDenganPeriode as $p)
@php
    $pAsprak = $periodeAktif[$p->id]['asprak'] ?? null;
    $pKoor   = $periodeAktif[$p->id]['koor']   ?? null;

    // Cek apakah user sudah terdaftar sebagai praktikan di praktikum ini
    $sudahTerdaftar = in_array($p->id, $praktikumDiikuti);

    // Cek pendaftaran yang sudah ada
    $existingAsprak = \Modules\EOffice\Models\PendaftaranAsprak::where('user_id', auth()->id())
        ->where('praktikum_id', $p->id)
        ->orderByDesc('created_at')
        ->first();
    $existingKoor = \Modules\EOffice\Models\PendaftaranKoordinator::where('user_id', auth()->id())
        ->where('praktikum_id', $p->id)
        ->orderByDesc('created_at')
        ->first();
@endphp

<div class="bg-white border border-[#DFE1E7] rounded-[14px] overflow-hidden shadow-[0_1px_2px_rgba(228,229,231,.24)]">

    {{-- Header --}}
    <div class="flex items-center gap-3 px-5 py-[10px] bg-[#FAFBFC] border-b border-[#DFE1E7]">
        <div class="flex-1 min-w-0">
            <div class="font-bold text-[13px] text-[#0D0D12] truncate">{{ $p->nama }}</div>
            <div class="text-[11px] text-[#666D80]">
                {{ $p->matkul?->kode ? '[' . $p->matkul->kode . '] · ' : '' }}{{ $p->semester }} {{ $p->tahun_ajaran }}
                @if($p->dosen) · {{ $p->dosen->name }} @endif
            </div>
        </div>
        @if($sudahTerdaftar)
        <span class="text-[10px] font-semibold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43] flex-shrink-0">
            ✓ Terdaftar sebagai praktikan
        </span>
        @else
        <span class="text-[10px] font-semibold px-2 py-[2px] rounded-full bg-[#F9ECCB] text-[#7C5309] flex-shrink-0">
            Belum ikut praktikum ini
        </span>
        @endif
    </div>

    {{-- Dua kolom: Asprak | Koor --}}
    <div class="grid grid-cols-2 divide-x divide-[#F0F1F4]">

        {{-- ── ASPRAK ───────────────────────────────────────────────── --}}
        <div>
            <div class="flex items-center justify-between px-4 py-[8px] border-b border-[#F0F1F4]"
                 style="background:{{ $pAsprak ? '#F0FDF9' : '#FAFBFC' }}">
                <span class="text-[12px] font-bold" style="color:{{ $pAsprak ? '#0D9488' : '#A4ABB8' }}">
                    Asisten Praktikum
                </span>
                @if($pAsprak)
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">● TERBUKA</span>
                @else
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#F0F1F4] text-[#A4ABB8]">TUTUP</span>
                @endif
            </div>

            <div class="p-4">
            @if(!$pAsprak)
                <div class="py-4 text-center text-[12px] text-[#A4ABB8]">Pendaftaran belum dibuka.</div>

            @elseif($sudahJadiAsprak)
                <div class="py-2 text-[12px] text-[#40C4AA] font-semibold">✓ Anda sudah aktif sebagai Asprak</div>

            @elseif($existingAsprak && in_array($existingAsprak->status, ['pending','approved']))
                {{-- Sudah daftar --}}
                <div class="text-[11px] text-[#666D80] mb-2 font-semibold">{{ $pAsprak->nama }}</div>
                <div class="flex items-center gap-2">
                    @if($existingAsprak->status === 'pending')
                    <span class="w-2 h-2 rounded-full bg-[#D39C3D]"></span>
                    <span class="text-[12px] text-[#7C5309] font-semibold">Menunggu seleksi koordinator</span>
                    @else
                    <span class="w-2 h-2 rounded-full bg-[#40C4AA]"></span>
                    <span class="text-[12px] text-[#174E43] font-semibold">Diterima!</span>
                    @endif
                </div>

            @else
                {{-- Form daftar asprak --}}
                @if($pAsprak->ditutup_pada)
                <div class="text-[11px] text-[#666D80] mb-3">
                    <span class="font-semibold">{{ $pAsprak->nama }}</span>
                    · Ditutup <span class="font-semibold text-[#DF1C41]">{{ $pAsprak->ditutup_pada->format('d M Y H:i') }}</span>
                    <span class="text-[#A4ABB8]">({{ $pAsprak->ditutup_pada->diffForHumans() }})</span>
                </div>
                @endif

                <form method="POST" action="{{ route('eoffice.manprak.mahasiswa.daftar-asprak.store') }}"
                      enctype="multipart/form-data" class="flex flex-col gap-3">
                    @csrf
                    <input type="hidden" name="praktikum_id" value="{{ $p->id }}">
                    <div>
                        <label class="block text-[11px] font-semibold text-[#353849] mb-1">IPK <span class="text-red-500">*</span></label>
                        <input type="number" name="ipk" step="0.01" min="0" max="4" required placeholder="3.50"
                               class="w-full border border-[#DFE1E7] rounded-[7px] px-2 py-[7px] text-[12px] focus:outline-none focus:border-[#40C4AA]">
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-[#353849] mb-1">Motivasi <span class="text-red-500">*</span></label>
                        <textarea name="motivasi" rows="3" required minlength="20"
                                  placeholder="Ceritakan pengalaman & motivasi Anda..."
                                  class="w-full border border-[#DFE1E7] rounded-[7px] px-2 py-[7px] text-[12px] focus:outline-none focus:border-[#40C4AA] resize-none"></textarea>
                    </div>
                    <div class="grid grid-cols-2 gap-2">
                        <div>
                            <label class="block text-[11px] font-semibold text-[#353849] mb-1">CV <span class="text-[#A4ABB8] font-normal">(PDF/DOCX)</span></label>
                            <input type="file" name="cv" accept=".pdf,.docx"
                                   class="w-full text-[11px] border border-[#DFE1E7] rounded-[7px] px-2 py-[5px]">
                        </div>
                        <div>
                            <label class="block text-[11px] font-semibold text-[#353849] mb-1">Transkrip <span class="text-[#A4ABB8] font-normal">(PDF)</span></label>
                            <input type="file" name="transkrip" accept=".pdf"
                                   class="w-full text-[11px] border border-[#DFE1E7] rounded-[7px] px-2 py-[5px]">
                        </div>
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-[#353849] mb-1">Jadwal Ketersediaan</label>
                        <div class="flex flex-wrap gap-3">
                            @foreach(['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $hari)
                            <label class="flex items-center gap-1 cursor-pointer">
                                <input type="checkbox" name="jadwal[]" value="{{ $hari }}" class="accent-[#40C4AA]">
                                <span class="text-[11px] text-[#353849]">{{ $hari }}</span>
                            </label>
                            @endforeach
                        </div>
                    </div>
                    <button type="submit"
                            class="w-full py-[8px] rounded-[8px] text-white text-[12px] font-semibold border-none cursor-pointer hover:opacity-90"
                            style="background:#40C4AA">
                        Kirim Pendaftaran Asprak
                    </button>
                </form>
            @endif
            </div>
        </div>

        {{-- ── KOOR ─────────────────────────────────────────────────── --}}
        <div>
            <div class="flex items-center justify-between px-4 py-[8px] border-b border-[#F0F1F4]"
                 style="background:{{ $pKoor ? '#EEF2FF' : '#FAFBFC' }}">
                <span class="text-[12px] font-bold" style="color:{{ $pKoor ? '#0B266E' : '#A4ABB8' }}">
                    Koordinator
                </span>
                @if($pKoor)
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#EEF2FF] text-[#0B266E]">● TERBUKA</span>
                @else
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#F0F1F4] text-[#A4ABB8]">TUTUP</span>
                @endif
            </div>

            <div class="p-4">
            @if(!$pKoor)
                <div class="py-4 text-center text-[12px] text-[#A4ABB8]">Pendaftaran belum dibuka.</div>

            @elseif($sudahJadiKoor)
                <div class="py-2 text-[12px] text-[#0B266E] font-semibold">✓ Anda sudah aktif sebagai Koordinator</div>

            @elseif($existingKoor && in_array($existingKoor->status, ['pending','approved']))
                <div class="text-[11px] text-[#666D80] mb-2 font-semibold">{{ $pKoor->nama }}</div>
                <div class="flex items-center gap-2">
                    @if($existingKoor->status === 'pending')
                    <span class="w-2 h-2 rounded-full bg-[#D39C3D]"></span>
                    <span class="text-[12px] text-[#7C5309] font-semibold">
                        {{ $existingKoor->status_dosen === 'disetujui' ? 'Disetujui dosen, menunggu Admin' : 'Menunggu review dosen' }}
                    </span>
                    @else
                    <span class="w-2 h-2 rounded-full bg-[#0B266E]"></span>
                    <span class="text-[12px] text-[#0B266E] font-semibold">Diterima sebagai Koordinator!</span>
                    @endif
                </div>

            @else
                @if($pKoor->ditutup_pada)
                <div class="text-[11px] text-[#666D80] mb-3">
                    <span class="font-semibold">{{ $pKoor->nama }}</span>
                    · Ditutup <span class="font-semibold text-[#DF1C41]">{{ $pKoor->ditutup_pada->format('d M Y H:i') }}</span>
                    <span class="text-[#A4ABB8]">({{ $pKoor->ditutup_pada->diffForHumans() }})</span>
                </div>
                @endif

                <form method="POST" action="{{ route('eoffice.manprak.mahasiswa.daftar-koor.store') }}"
                      enctype="multipart/form-data" class="flex flex-col gap-3">
                    @csrf
                    <input type="hidden" name="praktikum_id" value="{{ $p->id }}">
                    <div>
                        <label class="block text-[11px] font-semibold text-[#353849] mb-1">IPK <span class="text-red-500">*</span></label>
                        <input type="number" name="ipk" step="0.01" min="0" max="4" required placeholder="3.50"
                               class="w-full border border-[#DFE1E7] rounded-[7px] px-2 py-[7px] text-[12px] focus:outline-none focus:border-[#0B266E]">
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-[#353849] mb-1">Motivasi <span class="text-red-500">*</span></label>
                        <textarea name="motivasi" rows="3" required minlength="20"
                                  placeholder="Ceritakan motivasi Anda menjadi koordinator..."
                                  class="w-full border border-[#DFE1E7] rounded-[7px] px-2 py-[7px] text-[12px] focus:outline-none focus:border-[#0B266E] resize-none"></textarea>
                    </div>
                    <div>
                        <label class="block text-[11px] font-semibold text-[#353849] mb-1">Transkrip <span class="text-[#A4ABB8] font-normal">(PDF, opsional)</span></label>
                        <input type="file" name="transkrip" accept=".pdf"
                               class="w-full text-[11px] border border-[#DFE1E7] rounded-[7px] px-2 py-[5px]">
                    </div>
                    <button type="submit"
                            class="w-full py-[8px] rounded-[8px] text-white text-[12px] font-semibold border-none cursor-pointer hover:opacity-90"
                            style="background:#0B266E">
                        Kirim Pendaftaran Koordinator
                    </button>
                </form>
            @endif
            </div>
        </div>

    </div>{{-- end grid --}}
</div>
@endforeach

{{-- Daftar yang sudah lolos --}}
@if($asprakLolos->isNotEmpty() || $koorLolos->isNotEmpty())
<div class="bg-white border border-[#DFE1E7] rounded-[14px] overflow-hidden shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <div class="px-5 py-3 border-b border-[#DFE1E7] bg-[#FAFBFC] text-[13px] font-bold text-[#0D0D12]">
        Asisten & Koordinator Terpilih
    </div>
    <div class="grid grid-cols-2 divide-x divide-[#F0F1F4]">
        <div class="p-4">
            <div class="text-[11px] font-bold text-[#40C4AA] uppercase tracking-wide mb-2">Asisten Praktikum</div>
            @forelse($asprakLolos as $a)
            <div class="flex items-center gap-2 py-[6px] border-b border-[#F8F9FB] last:border-0">
                <div class="w-7 h-7 rounded-full bg-[#DDF2EE] flex items-center justify-center text-[10px] font-bold text-[#174E43] flex-shrink-0">
                    {{ strtoupper(substr($a->user?->name ?? '?', 0, 1)) }}
                </div>
                <div class="min-w-0">
                    <div class="text-[12px] font-semibold text-[#0D0D12] truncate">{{ $a->user?->name ?? '—' }}</div>
                    <div class="text-[10px] text-[#666D80]">{{ $a->praktikum?->nama }}</div>
                </div>
            </div>
            @empty
            <div class="text-[12px] text-[#A4ABB8] py-3">Belum ada.</div>
            @endforelse
        </div>
        <div class="p-4">
            <div class="text-[11px] font-bold text-[#0B266E] uppercase tracking-wide mb-2">Koordinator</div>
            @forelse($koorLolos as $k)
            <div class="flex items-center gap-2 py-[6px] border-b border-[#F8F9FB] last:border-0">
                <div class="w-7 h-7 rounded-full bg-[#EEF2FF] flex items-center justify-center text-[10px] font-bold text-[#0B266E] flex-shrink-0">
                    {{ strtoupper(substr($k->user?->name ?? '?', 0, 1)) }}
                </div>
                <div class="min-w-0">
                    <div class="text-[12px] font-semibold text-[#0D0D12] truncate">{{ $k->user?->name ?? '—' }}</div>
                    <div class="text-[10px] text-[#666D80]">{{ $k->praktikum?->nama }}</div>
                </div>
            </div>
            @empty
            <div class="text-[12px] text-[#A4ABB8] py-3">Belum ada.</div>
            @endforelse
        </div>
    </div>
</div>
@endif

@endif {{-- end $praktikumDenganPeriode->isEmpty() --}}

{{-- Syarat --}}
<div class="bg-white border border-[#DFE1E7] rounded-[14px] p-5 shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <div class="font-bold text-[13px] text-[#0D0D12] mb-3">Syarat Umum</div>
    <div class="grid grid-cols-2 gap-2">
        @foreach(['IPK minimal 3.00','Pernah mengikuti praktikum terkait','Tidak sedang mengambil praktikum yang sama','Bersedia hadir sesuai jadwal','Aktif sebagai mahasiswa','Menyetujui peraturan asisten praktikum'] as $s)
        <div class="flex items-center gap-2">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#40C4AA" stroke-width="2.5" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
            <span class="text-[12px] text-[#353849]">{{ $s }}</span>
        </div>
        @endforeach
    </div>
</div>

</x-eoffice::manajemen-praktikum.layout>