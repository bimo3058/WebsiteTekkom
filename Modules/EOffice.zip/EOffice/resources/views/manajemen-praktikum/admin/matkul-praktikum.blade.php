<x-eoffice::manajemen-praktikum.layout pageTitle="Mata Kuliah Praktikum">

<div class="flex items-center justify-between flex-shrink-0">
    <div>
        <div class="text-[20px] font-bold text-[#0D0D12]">Mata Kuliah Praktikum</div>
        <div class="text-[12px] text-[#666D80] mt-[2px]">
            Daftar mata kuliah yang memiliki komponen praktikum — Kurikulum 2024 S1 Teknik Komputer UNDIP
        </div>
    </div>
    <button onclick="document.getElementById('modal-tambah').classList.remove('hidden')"
            class="flex items-center gap-2 px-4 py-[9px] rounded-[9px] bg-[#0B266E] text-white text-[13px] font-semibold border-none cursor-pointer hover:bg-[#0a1f5c]">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Tambah Matkul
    </button>
</div>

@if(session('success'))
<div class="bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] px-4 py-3 text-[13px] text-[#174E43]">{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="bg-[#FADAE1] border border-[#DF1C41] rounded-[10px] px-4 py-3 text-[13px] text-[#7C1028]">{{ session('error') }}</div>
@endif

{{-- Filter & search --}}
<div class="flex gap-2 flex-wrap items-center">
    <form method="GET" class="flex gap-2 flex-wrap">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari kode atau nama..."
               class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E] w-[220px]">
        <select name="semester" class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            <option value="">Semua Semester</option>
            @for($s = 1; $s <= 8; $s++)
            <option value="{{ $s }}" {{ request('semester') == $s ? 'selected' : '' }}>Semester {{ $s }}</option>
            @endfor
        </select>
        <button type="submit" class="px-4 py-[8px] rounded-[8px] bg-[#0B266E] text-white text-[13px] font-semibold border-none cursor-pointer">Filter</button>
        @if(request()->hasAny(['search','semester']))
        <a href="{{ route('eoffice.manprak.admin.matkul-praktikum.index') }}"
           class="px-4 py-[8px] rounded-[8px] border border-[#DFE1E7] text-[13px] text-[#666D80] no-underline hover:bg-[#F6F8FA]">Reset</a>
        @endif
    </form>
    <div class="ml-auto text-[12px] text-[#666D80]">Total: <strong>{{ $matkulList->total() }}</strong> matkul</div>
</div>

{{-- Tabel per semester --}}
@php
    $grouped = $matkulList->getCollection()->groupBy('semester');
@endphp

@foreach($grouped->sortKeys() as $sem => $items)
<div class="bg-white border border-[#DFE1E7] rounded-[14px] overflow-hidden shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <div class="px-5 py-3 bg-[#FAFBFC] border-b border-[#DFE1E7] flex items-center gap-3">
        <span class="text-[11px] font-bold px-3 py-[3px] rounded-full bg-[#EEF2FF] text-[#0B266E]">Semester {{ $sem }}</span>
        <span class="text-[12px] font-semibold text-[#0D0D12]">{{ $items->count() }} mata kuliah</span>
    </div>
    <table class="w-full text-[13px]">
        <thead>
            <tr class="border-b border-[#F0F1F4]">
                <th class="text-left py-2 px-5 text-[11px] font-semibold text-[#666D80] w-[160px]">Kode MK</th>
                <th class="text-left py-2 px-5 text-[11px] font-semibold text-[#666D80]">Nama Mata Kuliah</th>
                <th class="text-left py-2 px-5 text-[11px] font-semibold text-[#666D80] w-[60px]">SKS</th>
                <th class="text-left py-2 px-5 text-[11px] font-semibold text-[#666D80] w-[120px]">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($items as $mk)
            <tr class="border-b border-[#F8F9FB] last:border-0 hover:bg-[#FAFAFC]">
                <td class="py-3 px-5">
                    <span class="font-mono text-[12px] font-semibold text-[#0B266E] bg-[#EEF2FF] px-2 py-[2px] rounded">{{ $mk->kode }}</span>
                </td>
                <td class="py-3 px-5 font-medium text-[#0D0D12]">{{ $mk->nama }}</td>
                <td class="py-3 px-5 text-center font-bold text-[#353849]">{{ $mk->sks }}</td>
                <td class="py-3 px-5">
                    <div class="flex gap-2">
                        <button onclick="openEdit({{ $mk->id }}, '{{ addslashes($mk->kode) }}', '{{ addslashes($mk->nama) }}', {{ $mk->sks }}, {{ $mk->semester ?? 'null' }})"
                                class="text-[11px] font-semibold px-3 py-[4px] rounded-[6px] border border-[#DFE1E7] text-[#353849] bg-white cursor-pointer hover:bg-[#F6F8FA]">
                            Edit
                        </button>
                        <form method="POST" action="{{ route('eoffice.manprak.admin.matkul-praktikum.destroy', $mk->id) }}"
                              onsubmit="return confirm('Hapus {{ addslashes($mk->nama) }}?')">
                            @csrf @method('DELETE')
                            <button type="submit"
                                    class="text-[11px] font-semibold px-3 py-[4px] rounded-[6px] bg-[#FADAE1] text-[#7C1028] border-none cursor-pointer hover:bg-[#f5c0cc]">
                                Hapus
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endforeach

@if($matkulList->isEmpty())
<div class="bg-white border border-[#DFE1E7] rounded-[14px] py-12 text-center text-[13px] text-[#A4ABB8]">
    Belum ada mata kuliah praktikum.
</div>
@endif

@if($matkulList->hasPages())
<div>{{ $matkulList->links() }}</div>
@endif

{{-- Modal Tambah --}}
<div id="modal-tambah" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/40">
    <div class="bg-white rounded-[16px] w-full max-w-md mx-4 shadow-2xl">
        <div class="px-6 py-4 border-b border-[#DFE1E7] flex items-center justify-between">
            <div class="font-bold text-[15px] text-[#0D0D12]">Tambah Mata Kuliah Praktikum</div>
            <button onclick="document.getElementById('modal-tambah').classList.add('hidden')"
                    class="text-[#A4ABB8] hover:text-[#353849] bg-transparent border-none cursor-pointer text-[20px] leading-none">×</button>
        </div>
        <form method="POST" action="{{ route('eoffice.manprak.admin.matkul-praktikum.store') }}" class="px-6 py-5 flex flex-col gap-4">
            @csrf
            <div>
                <label class="block text-[12px] font-semibold text-[#353849] mb-1">Kode MK <span class="text-red-500">*</span></label>
                <input type="text" name="kode" required placeholder="cth: TSK1624107" maxlength="20"
                       class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] font-mono focus:outline-none focus:border-[#0B266E]">
            </div>
            <div>
                <label class="block text-[12px] font-semibold text-[#353849] mb-1">Nama Mata Kuliah <span class="text-red-500">*</span></label>
                <input type="text" name="nama" required placeholder="cth: Praktikum Pemrograman Dasar"
                       class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[12px] font-semibold text-[#353849] mb-1">SKS <span class="text-red-500">*</span></label>
                    <input type="number" name="sks" required min="1" max="6" placeholder="1"
                           class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
                </div>
                <div>
                    <label class="block text-[12px] font-semibold text-[#353849] mb-1">Semester</label>
                    <select name="semester" class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
                        <option value="">— Pilih —</option>
                        @for($s = 1; $s <= 8; $s++)
                        <option value="{{ $s }}">Semester {{ $s }}</option>
                        @endfor
                    </select>
                </div>
            </div>
            <div class="flex justify-end gap-2 pt-1">
                <button type="button" onclick="document.getElementById('modal-tambah').classList.add('hidden')"
                        class="px-4 py-[8px] rounded-[8px] border border-[#DFE1E7] text-[13px] text-[#353849] bg-white cursor-pointer hover:bg-[#F6F8FA]">Batal</button>
                <button type="submit"
                        class="px-5 py-[8px] rounded-[8px] bg-[#0B266E] text-white text-[13px] font-semibold border-none cursor-pointer hover:bg-[#0a1f5c]">Simpan</button>
            </div>
        </form>
    </div>
</div>

{{-- Modal Edit --}}
<div id="modal-edit" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black/40">
    <div class="bg-white rounded-[16px] w-full max-w-md mx-4 shadow-2xl">
        <div class="px-6 py-4 border-b border-[#DFE1E7] flex items-center justify-between">
            <div class="font-bold text-[15px] text-[#0D0D12]">Edit Mata Kuliah Praktikum</div>
            <button onclick="document.getElementById('modal-edit').classList.add('hidden')"
                    class="text-[#A4ABB8] hover:text-[#353849] bg-transparent border-none cursor-pointer text-[20px] leading-none">×</button>
        </div>
        <form id="form-edit" method="POST" action="" class="px-6 py-5 flex flex-col gap-4">
            @csrf @method('PUT')
            <div>
                <label class="block text-[12px] font-semibold text-[#353849] mb-1">Kode MK <span class="text-red-500">*</span></label>
                <input type="text" id="edit-kode" name="kode" required maxlength="20"
                       class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] font-mono focus:outline-none focus:border-[#0B266E]">
            </div>
            <div>
                <label class="block text-[12px] font-semibold text-[#353849] mb-1">Nama Mata Kuliah <span class="text-red-500">*</span></label>
                <input type="text" id="edit-nama" name="nama" required
                       class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[12px] font-semibold text-[#353849] mb-1">SKS <span class="text-red-500">*</span></label>
                    <input type="number" id="edit-sks" name="sks" required min="1" max="6"
                           class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
                </div>
                <div>
                    <label class="block text-[12px] font-semibold text-[#353849] mb-1">Semester</label>
                    <select id="edit-semester" name="semester"
                            class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
                        <option value="">— Pilih —</option>
                        @for($s = 1; $s <= 8; $s++)
                        <option value="{{ $s }}">Semester {{ $s }}</option>
                        @endfor
                    </select>
                </div>
            </div>
            <div class="flex justify-end gap-2 pt-1">
                <button type="button" onclick="document.getElementById('modal-edit').classList.add('hidden')"
                        class="px-4 py-[8px] rounded-[8px] border border-[#DFE1E7] text-[13px] text-[#353849] bg-white cursor-pointer hover:bg-[#F6F8FA]">Batal</button>
                <button type="submit"
                        class="px-5 py-[8px] rounded-[8px] bg-[#0B266E] text-white text-[13px] font-semibold border-none cursor-pointer hover:bg-[#0a1f5c]">Perbarui</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEdit(id, kode, nama, sks, semester) {
    const base = '{{ url("eoffice/manprak/admin/matkul-praktikum") }}';
    document.getElementById('form-edit').action = base + '/' + id;
    document.getElementById('edit-kode').value = kode;
    document.getElementById('edit-nama').value = nama;
    document.getElementById('edit-sks').value = sks;
    const sel = document.getElementById('edit-semester');
    for (let o of sel.options) o.selected = (parseInt(o.value) === semester);
    document.getElementById('modal-edit').classList.remove('hidden');
}
</script>

</x-eoffice::manajemen-praktikum.layout>
