<x-eoffice::manajemen-praktikum.layout pageTitle="Periode Pendaftaran">

<div>
    <div class="text-[20px] font-bold text-[#0D0D12]">Periode Pendaftaran</div>
    <div class="text-[12px] text-[#666D80] mt-[2px]">Buka / tutup periode pendaftaran koor & asprak per mata kuliah praktikum</div>
</div>

@if(session('success'))
<div class="bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] px-4 py-3 text-[13px] text-[#174E43] flex items-center gap-2">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><polyline points="20 6 9 17 4 12"/></svg>
    {{ session('success') }}
</div>
@endif
@if(session('error'))
<div class="bg-[#FADAE1] border border-[#DF1C41] rounded-[10px] px-4 py-3 text-[13px] text-[#7C1028]">{{ session('error') }}</div>
@endif

{{-- ── FORM BUKA PERIODE ───────────────────────────────────────────────── --}}
<div class="bg-white border border-[#DFE1E7] rounded-[14px] p-6 shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <div class="font-bold text-[15px] text-[#0D0D12] mb-5">Buka Periode Pendaftaran Baru</div>

    {{-- Step 1: Pilih Mata Kuliah — selalu tampil, submit GET untuk filter --}}
    <form method="GET" action="{{ route('eoffice.manprak.admin.periode-pendaftaran.index') }}" id="form-matkul">
        <label class="block text-[12px] font-semibold text-[#353849] mb-1">
            1. Pilih Mata Kuliah Praktikum <span class="text-red-500">*</span>
        </label>
        <select name="matkul_id" onchange="document.getElementById('form-matkul').submit()"
                class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            <option value="">— Pilih Mata Kuliah Praktikum —</option>
            @foreach($matkulList->groupBy('semester') as $sem => $items)
            <optgroup label="Semester {{ $sem }}">
                @foreach($items as $mk)
                <option value="{{ $mk->id }}" {{ $matkulId == $mk->id ? 'selected' : '' }}>
                    [{{ $mk->kode }}] {{ $mk->nama }} ({{ $mk->sks }} SKS)
                </option>
                @endforeach
            </optgroup>
            @endforeach
        </select>
        @if($matkulList->isEmpty())
        <p class="mt-1 text-[11px] text-[#DF1C41]">
            ⚠ Belum ada data matkul. Jalankan:
            <code class="bg-[#F6F8FA] px-1 rounded">php artisan db:seed --class=MatkulPraktikumSeeder</code>
        </p>
        @endif
    </form>

    @if($matkulDipilih)

    {{-- Info matkul terpilih --}}
    <div class="mt-4 flex items-center gap-3 px-4 py-3 bg-[#EEF2FF] rounded-[10px]">
        <span class="font-mono text-[12px] font-bold text-[#0B266E] bg-white px-2 py-[2px] rounded border border-[#C7D2FE]">
            {{ $matkulDipilih->kode }}
        </span>
        <div class="flex-1 text-[13px] font-semibold text-[#0D0D12]">{{ $matkulDipilih->nama }}</div>
        <span class="text-[11px] text-[#666D80]">Sem {{ $matkulDipilih->semester }} · {{ $matkulDipilih->sks }} SKS</span>
    </div>

    {{-- Jika belum ada praktikum yang di-link ke matkul ini → tampilkan form assign --}}
    @if($praktikumLinked->isEmpty())

    <div class="mt-4 bg-[#FEF9EC] border border-[#D39C3D] rounded-[10px] px-4 py-4">
        <div class="text-[13px] font-semibold text-[#7C5309] mb-1">
            ⚠ Belum ada praktikum yang terhubung ke mata kuliah ini
        </div>
        <div class="text-[12px] text-[#956321] mb-3">
            Hubungkan salah satu praktikum aktif ke mata kuliah ini, atau
            <a href="{{ route('eoffice.manprak.admin.praktikum.index') }}" class="underline font-semibold">buat praktikum baru</a>.
        </div>

        @if($praktikumSemua->isNotEmpty())
        <form method="POST" action="{{ route('eoffice.manprak.admin.periode-pendaftaran.assign-matkul') }}"
              class="flex gap-2 flex-wrap items-end">
            @csrf
            <input type="hidden" name="matkul_id" value="{{ $matkulDipilih->id }}">
            <div class="flex-1 min-w-[240px]">
                <label class="block text-[11px] font-semibold text-[#7C5309] mb-1">Pilih praktikum yang ingin dihubungkan:</label>
                <select name="praktikum_id" required
                        class="w-full border border-[#D39C3D] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E] bg-white">
                    <option value="">— Pilih Praktikum —</option>
                    @foreach($praktikumSemua as $p)
                    <option value="{{ $p->id }}">
                        {{ $p->nama }}
                        @if($p->kode) [{{ $p->kode }}] @endif
                        · {{ $p->semester }} {{ $p->tahun_ajaran }}
                        @if($p->matkul) · ({{ $p->matkul->kode }}) @endif
                    </option>
                    @endforeach
                </select>
            </div>
            <button type="submit"
                    class="px-4 py-[9px] rounded-[8px] bg-[#D39C3D] text-white text-[13px] font-semibold border-none cursor-pointer hover:bg-[#b88530] whitespace-nowrap">
                Hubungkan & Lanjutkan
            </button>
        </form>
        @else
        <a href="{{ route('eoffice.manprak.admin.praktikum.index') }}"
           class="inline-flex items-center gap-2 px-4 py-[8px] rounded-[8px] bg-[#0B266E] text-white text-[13px] font-semibold no-underline hover:bg-[#0a1f5c]">
            Buat Praktikum Baru →
        </a>
        @endif
    </div>

    @else

    {{-- Ada praktikum yang terhubung → tampilkan form buka periode --}}
    <form method="POST" action="{{ route('eoffice.manprak.admin.periode-pendaftaran.store') }}"
          class="mt-5 flex flex-col gap-4">
        @csrf
        {{-- Preserve matkul_id agar filter tetap aktif setelah submit --}}
        <input type="hidden" name="matkul_id_filter" value="{{ $matkulDipilih->id }}">

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-[12px] font-semibold text-[#353849] mb-1">
                    2. Pilih Praktikum <span class="text-red-500">*</span>
                </label>
                <select name="praktikum_id" required
                        class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
                    <option value="">— Pilih Praktikum —</option>
                    @foreach($praktikumLinked as $p)
                    <option value="{{ $p->id }}" {{ $praktikumId == $p->id ? 'selected' : '' }}>
                        {{ $p->nama }}
                        @if($p->kode) [{{ $p->kode }}] @endif
                        · {{ $p->semester }} {{ $p->tahun_ajaran }}
                        @if($p->dosen) · {{ $p->dosen->name }} @endif
                    </option>
                    @endforeach
                </select>
            </div>
            <div>
                <label class="block text-[12px] font-semibold text-[#353849] mb-1">
                    3. Jenis Pendaftaran <span class="text-red-500">*</span>
                </label>
                <select name="jenis" required
                        class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
                    <option value="koor">Koordinator Praktikum</option>
                    <option value="asprak">Asisten Praktikum</option>
                </select>
            </div>
            <div>
                <label class="block text-[12px] font-semibold text-[#353849] mb-1">
                    Nama Periode <span class="text-[#A4ABB8] font-normal">(opsional)</span>
                </label>
                <input type="text" name="nama" placeholder="cth: Koor Ganjil 2025/2026"
                       class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div>
                    <label class="block text-[12px] font-semibold text-[#353849] mb-1">Dibuka Pada</label>
                    <input type="datetime-local" name="dibuka_pada"
                           class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
                </div>
                <div>
                    <label class="block text-[12px] font-semibold text-[#353849] mb-1">Ditutup Pada</label>
                    <input type="datetime-local" name="ditutup_pada"
                           class="w-full border border-[#DFE1E7] rounded-[8px] px-3 py-[9px] text-[13px] focus:outline-none focus:border-[#0B266E]">
                </div>
            </div>
        </div>

        <div class="p-3 bg-[#EEF2FF] rounded-[8px] text-[12px] text-[#0B266E]">
            <strong>ℹ️ Info:</strong> Setelah dibuka, notifikasi dikirim ke <strong>seluruh pengguna</strong> aktif di sistem.
        </div>

        <div class="flex justify-end">
            <button type="submit"
                    class="px-6 py-[10px] rounded-[10px] bg-[#0B266E] text-white text-[13px] font-semibold border-none cursor-pointer hover:bg-[#0a1f5c]">
                Buka Periode & Kirim Notifikasi
            </button>
        </div>
    </form>

    @endif {{-- end $praktikumLinked->isEmpty() --}}

    @else
    {{-- Belum pilih matkul --}}
    <div class="mt-4 bg-[#F6F8FA] border border-dashed border-[#DFE1E7] rounded-[10px] py-8 text-center text-[13px] text-[#A4ABB8]">
        Pilih mata kuliah praktikum di atas untuk melanjutkan.
    </div>
    @endif {{-- end $matkulDipilih --}}

</div>

{{-- ── RIWAYAT PERIODE ─────────────────────────────────────────────────── --}}
<div class="flex items-center gap-3 flex-wrap">
    <div class="text-[13px] font-semibold text-[#353849]">Riwayat Periode</div>
    <form method="GET" class="flex gap-2 items-center">
        @if($matkulId)<input type="hidden" name="matkul_id" value="{{ $matkulId }}">@endif
        <select name="praktikum_id" onchange="this.form.submit()"
                class="border border-[#DFE1E7] rounded-[8px] px-3 py-[7px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            <option value="">Semua Praktikum</option>
            @foreach($praktikumLinked as $p)
            <option value="{{ $p->id }}" {{ $praktikumId == $p->id ? 'selected' : '' }}>{{ $p->nama }}</option>
            @endforeach
        </select>
    </form>
</div>

<div class="bg-white border border-[#DFE1E7] rounded-[14px] overflow-hidden shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <div class="px-5 py-3 border-b border-[#DFE1E7] bg-[#FAFBFC] text-[13px] font-bold text-[#0D0D12]">
        Riwayat Periode Pendaftaran
    </div>
    @forelse($periodeList as $periode)
    @php $sedangBuka = $periode->isSedangBuka(); @endphp
    <div class="flex items-center px-5 py-4 border-b border-[#F8F9FB] last:border-0 hover:bg-[#FAFAFC] gap-4">
        <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2 mb-1 flex-wrap">
                <div class="text-[14px] font-bold text-[#0D0D12]">{{ $periode->nama }}</div>
                @if($periode->is_aktif && $sedangBuka)
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">● AKTIF</span>
                @elseif($periode->is_aktif && !$sedangBuka)
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#F9ECCB] text-[#7C5309]">TERJADWAL</span>
                @else
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#F0F1F4] text-[#666D80]">DITUTUP</span>
                @endif
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full {{ $periode->jenis === 'koor' ? 'bg-[#EEF2FF] text-[#0B266E]' : 'bg-[#F0FDF9] text-[#0D9488]' }}">
                    {{ strtoupper($periode->jenis) }}
                </span>
            </div>
            <div class="text-[12px] text-[#666D80]">
                Praktikum: <span class="font-medium text-[#353849]">{{ $periode->praktikum?->nama ?? '—' }}</span>
                @if($periode->praktikum?->matkul)
                · <span class="font-mono text-[11px] bg-[#EEF2FF] text-[#0B266E] px-1 rounded">{{ $periode->praktikum->matkul->kode }}</span>
                @endif
                @if($periode->dibuka_pada) · Buka: <span class="font-medium">{{ $periode->dibuka_pada->format('d M Y H:i') }}</span> @endif
                @if($periode->ditutup_pada) · Tutup: <span class="font-medium">{{ $periode->ditutup_pada->format('d M Y H:i') }}</span> @endif
            </div>
            <div class="text-[11px] text-[#A4ABB8] mt-[2px]">
                Dibuka oleh: {{ $periode->dibukaOleh?->name ?? '—' }} · {{ $periode->created_at?->format('d M Y') }}
            </div>
        </div>
        <div class="flex gap-2 flex-shrink-0">
            @if($periode->is_aktif)
            <form method="POST" action="{{ route('eoffice.manprak.admin.periode-pendaftaran.tutup', $periode->id) }}">
                @csrf
                <button type="submit" class="text-[12px] font-semibold px-3 py-[6px] rounded-[7px] bg-[#F9ECCB] text-[#7C5309] border-none cursor-pointer hover:bg-[#f0e0b0]">Tutup</button>
            </form>
            @endif
            <form method="POST" action="{{ route('eoffice.manprak.admin.periode-pendaftaran.destroy', $periode->id) }}"
                  onsubmit="return confirm('Hapus periode ini?')">
                @csrf @method('DELETE')
                <button type="submit" class="text-[12px] font-semibold px-3 py-[6px] rounded-[7px] bg-[#FADAE1] text-[#7C1028] border-none cursor-pointer hover:bg-[#f5c0cc]">Hapus</button>
            </form>
        </div>
    </div>
    @empty
    <div class="py-10 text-center text-[13px] text-[#A4ABB8]">Belum ada periode pendaftaran.</div>
    @endforelse
</div>

{{-- ── RIWAYAT PENGUMUMAN SISTEM ──────────────────────────────────────── --}}
@if($riwayatPengumuman->isNotEmpty())
<div>
    <div class="text-[13px] font-semibold text-[#353849]">Riwayat Pengumuman Sistem Otomatis</div>
    <div class="text-[11px] text-[#A4ABB8]">Pengumuman yang dibuat otomatis saat periode dibuka/ditutup, termasuk yang sudah dihapus dari tampilan publik.</div>
</div>

<div class="bg-white border border-[#DFE1E7] rounded-[14px] overflow-hidden shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    @foreach($riwayatPengumuman as $pg)
    @php $dihapus = !is_null($pg->deleted_at); @endphp
    <div class="flex items-start px-5 py-4 border-b border-[#F8F9FB] last:border-0 gap-4 {{ $dihapus ? 'opacity-60' : '' }}">
        <div class="flex-1 min-w-0">
            <div class="flex items-center gap-2 flex-wrap mb-1">
                <span class="text-[13px] font-semibold text-[#0D0D12]">{{ $pg->judul }}</span>
                @if($pg->tipe_sistem === 'buka')
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">BUKA</span>
                @else
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#FADAE1] text-[#7C1028]">TUTUP</span>
                @endif
                @if($dihapus)
                <span class="text-[10px] font-bold px-2 py-[2px] rounded-full bg-[#F0F1F4] text-[#666D80]">Disembunyikan dari publik</span>
                @endif
            </div>
            <div class="text-[12px] text-[#666D80]">
                Praktikum: <span class="font-medium text-[#353849]">{{ $pg->praktikum?->nama ?? '—' }}</span>
                · Dibuat: <span class="font-medium">{{ $pg->created_at?->format('d M Y, H:i') }}</span>
                @if($dihapus)
                · Disembunyikan: <span class="font-medium text-[#DF1C41]">{{ $pg->deleted_at->format('d M Y, H:i') }}</span>
                @endif
            </div>
        </div>
    </div>
    @endforeach
</div>
@endif

</x-eoffice::manajemen-praktikum.layout>