<x-eoffice::manajemen-praktikum.layout pageTitle="Pendaftaran Koordinator">

<div>
    <div class="text-[20px] font-bold text-[#0D0D12]">Pendaftaran Koordinator Praktikum</div>
    <div class="text-[12px] text-[#666D80] mt-[2px]">Final approval setelah dosen menyetujui pendaftar</div>
</div>

{{-- Flow info --}}
<div class="bg-[#EEF2FF] border border-[#C7D2FE] rounded-[10px] px-4 py-3 text-[12px] text-[#0B266E]">
    <strong>Alur:</strong> Mahasiswa mendaftar → Dosen pengampu review & setujui → Admin melakukan final approval → Role <code>koor_prak</code> di-assign otomatis.
    Anda hanya bisa approve jika dosen sudah menyetujui.
</div>

@if(session('success'))
<div class="bg-[#DDF2EE] border border-[#40C4AA] rounded-[10px] px-4 py-3 text-[13px] text-[#174E43]">{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="bg-[#FADAE1] border border-[#DF1C41] rounded-[10px] px-4 py-3 text-[13px] text-[#7C1028]">{{ session('error') }}</div>
@endif

{{-- Filter --}}
<div class="flex gap-2">
    <form method="GET" class="flex gap-2 flex-wrap">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Cari nama mahasiswa..."
               class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E] w-[200px]">
        <select name="status_dosen" class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            <option value="">Semua Status Dosen</option>
            <option value="menunggu"  {{ request('status_dosen')=='menunggu'  ? 'selected' : '' }}>Menunggu Review Dosen</option>
            <option value="disetujui" {{ request('status_dosen')=='disetujui' ? 'selected' : '' }}>Disetujui Dosen (Siap Approve)</option>
            <option value="ditolak"   {{ request('status_dosen')=='ditolak'   ? 'selected' : '' }}>Ditolak Dosen</option>
        </select>
        <select name="status" class="border border-[#DFE1E7] rounded-[8px] px-3 py-[8px] text-[13px] focus:outline-none focus:border-[#0B266E]">
            <option value="">Semua Status Admin</option>
            <option value="pending"  {{ request('status')=='pending'  ? 'selected' : '' }}>Pending</option>
            <option value="approved" {{ request('status')=='approved' ? 'selected' : '' }}>Approved</option>
            <option value="rejected" {{ request('status')=='rejected' ? 'selected' : '' }}>Rejected</option>
        </select>
        <button type="submit" class="px-4 py-[8px] rounded-[8px] bg-[#0B266E] text-white text-[13px] font-semibold border-none cursor-pointer">Filter</button>
    </form>
</div>

<div class="bg-white border border-[#DFE1E7] rounded-[14px] overflow-hidden shadow-[0_1px_2px_rgba(228,229,231,.24)]">
    <div class="overflow-x-auto">
        <table class="w-full text-[13px]">
            <thead class="bg-[#FAFBFC] border-b border-[#DFE1E7]">
                <tr>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Mahasiswa</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Praktikum</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">IPK</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Status Dosen</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Status Admin</th>
                    <th class="text-left py-3 px-4 text-[11px] font-semibold text-[#666D80]">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($pendaftaran as $p)
                <tr class="border-b border-[#F8F9FB] hover:bg-[#FAFAFC]">
                    <td class="py-3 px-4">
                        <div class="font-semibold text-[#0D0D12]">{{ $p->user?->name ?? '—' }}</div>
                        <div class="text-[11px] text-[#666D80]">{{ $p->user?->email }}</div>
                    </td>
                    <td class="py-3 px-4 text-[#353849]">{{ $p->praktikum?->nama ?? '—' }}</td>
                    <td class="py-3 px-4 font-bold text-[#0D0D12]">{{ number_format($p->ipk, 2) }}</td>
                    <td class="py-3 px-4">
                        @if($p->status_dosen === 'disetujui')
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">✓ Disetujui Dosen</span>
                        @elseif($p->status_dosen === 'ditolak')
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#FADAE1] text-[#7C1028]">✗ Ditolak Dosen</span>
                        @else
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#F9ECCB] text-[#7C5309]">⏳ Menunggu Dosen</span>
                        @endif
                        @if($p->catatan_dosen)
                        <div class="text-[10px] text-[#666D80] mt-[2px]">{{ Str::limit($p->catatan_dosen, 40) }}</div>
                        @endif
                    </td>
                    <td class="py-3 px-4">
                        @if($p->status === 'approved')
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#DDF2EE] text-[#174E43]">Approved</span>
                        @elseif($p->status === 'rejected')
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#FADAE1] text-[#7C1028]">Rejected</span>
                        @else
                        <span class="text-[11px] font-semibold px-2 py-[2px] rounded-full bg-[#F0F1F4] text-[#666D80]">Pending</span>
                        @endif
                    </td>
                    <td class="py-3 px-4">
                        @if($p->status === 'pending' && $p->status_dosen === 'disetujui')
                        <div class="flex gap-2" x-data="{}">
                            <form method="POST" action="{{ route('eoffice.manprak.admin.pendaftaran-koor.approve', $p->id) }}">
                                @csrf
                                <button type="submit"
                                        class="text-[12px] font-semibold px-3 py-[5px] rounded-[7px] bg-[#DDF2EE] text-[#174E43] border-none cursor-pointer hover:bg-[#c0e8e0]">
                                    Final Approve
                                </button>
                            </form>
                            <form method="POST" action="{{ route('eoffice.manprak.admin.pendaftaran-koor.reject', $p->id) }}" x-data="{ alasan: '' }">
                                @csrf
                                <input type="hidden" name="alasan_penolakan" :value="alasan">
                                <button type="button"
                                        @click="alasan = prompt('Alasan penolakan:'); if(alasan !== null) $el.closest('form').submit()"
                                        class="text-[12px] font-semibold px-3 py-[5px] rounded-[7px] bg-[#FADAE1] text-[#7C1028] border-none cursor-pointer hover:bg-[#f5c0cc]">
                                    Tolak
                                </button>
                            </form>
                        </div>
                        @elseif($p->status === 'pending' && $p->status_dosen === 'menunggu')
                        <span class="text-[11px] text-[#A4ABB8]">Menunggu dosen review</span>
                        @elseif($p->status !== 'pending')
                        <span class="text-[11px] text-[#A4ABB8]">Sudah diproses</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="py-10 text-center text-[13px] text-[#A4ABB8]">Tidak ada data pendaftaran.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($pendaftaran->hasPages())
    <div class="px-4 py-3 border-t border-[#DFE1E7]">{{ $pendaftaran->links() }}</div>
    @endif
</div>

</x-eoffice::manajemen-praktikum.layout>
